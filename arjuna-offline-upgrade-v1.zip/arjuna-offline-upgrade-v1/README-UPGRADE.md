# Arjuna Offline Simulation Upgrade v1

This is an upgrade of the web application recovered from the uploaded Arjuna APK.
It preserves the existing HTML/CSS/vanilla-JavaScript architecture and the original
664 concept IDs.

## What is included in this build

- Existing Arjuna web application source extracted from `assets/www/` in the APK.
- Original concept index (`assets/js/data.js`) with 664 records and local simulation mapping metadata.
- Local simulation registry and player.
- Ten original interactive offline simulations:
  1. Projectile Motion
  2. Vector Addition
  3. Newton's Second Law
  4. Work and Energy
  5. Circular Motion
  6. Simple Pendulum
  7. Ohm's Law
  8. Lens Formula
  9. Mole Concept
  10. Quadratic Function Graph Explorer
- New `#/lab` route and `#/lab/<simulation-id>` player routes.
- Concept pages show a local-lab launch card when a relevant module is mapped.
- Updated service-worker cache version and shell asset list.
- Offline simulation smoke tests.

## Architecture

No framework migration was performed. The application remains HTML, CSS and vanilla JavaScript.
The local player uses Canvas, native range inputs, local calculations and localStorage for
saved observations. Simulation files are bundled locally. The experiment calculations do
not call remote APIs.

## Run locally

Serve this folder from a local HTTP server (service workers require a secure context such as
localhost or HTTPS). Open `index.html` through that server.

The PWA shell and listed simulation scripts are added to the service-worker precache list.
Test on the target Android WebView separately.

## Test

Run:

    node tests/simulation-smoke-test.js

Syntax checks can be run with:

    node --check assets/js/app.js
    node --check assets/js/simulations/registry.js
    node --check assets/js/simulations/player.js
    node --check assets/js/data.js

## Important scope and limitations

- This build contains 10 functional original simulation modules, not 664 complete interactive
  simulations. The 664 syllabus/concept records are preserved; 121 records are mapped to one
  of these initial modules as related learning entry points. That mapping is not a claim that
  each mapped concept is fully covered.
- More advanced simulations and subject coverage must be developed and scientifically verified
  in additional batches.
- Hindi and Marathi selector labels are included in the player, but full translation of every
  scientific explanation, label and syllabus concept is not yet complete.
- The initial build bundles the 10 modules with the application. A separate per-experiment
  package download/install manager is not yet implemented.
- The existing Android APK wrapper source, Gradle project and signing configuration were not
  present in the APK. This archive is the upgraded web source, not a signed Android APK.
  To produce a new installable APK, this source must be placed in the original wrapper project
  or a compatible Android WebView wrapper must be built and signed.
- Third-party source links remain available as references. They are not converted into offline
  simulations by this upgrade.

## Preserve and extend

Keep existing concept IDs stable. Add new simulations as separate modules in
`assets/js/simulations/`, register them in `registry.js`, map relevant concept records in
`data.js`, and add scientific tests before publishing.
