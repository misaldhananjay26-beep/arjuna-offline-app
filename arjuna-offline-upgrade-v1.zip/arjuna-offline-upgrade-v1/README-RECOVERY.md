# Arjuna recovered web source

This folder contains the web application files packaged inside the uploaded Android APK under `assets/www/`.

## Included
- `index.html`
- `assets/css/styles.css`
- `assets/js/app.js`
- `assets/js/data.js` (the 664-record concept index)
- `assets/js/search.js`
- `assets/js/vendor/motion.js`
- `sw.js`
- `manifest.webmanifest`
- packaged icons and images

## Important limitations
- This is the recoverable web layer bundled in the APK, not the original complete development repository.
- The Android wrapper source (for example, original Java/Kotlin project, Gradle files, signing setup and build configuration) is not included as a source project.
- Keep an untouched backup before making changes.
- No APK signing keys or private credentials are included.
- The existing app's external learning resources remain external; this recovered source does not contain the original third-party simulation engines.

## Recommended next step
Create a separate working copy and add the local simulation registry/player incrementally. Preserve the existing concept IDs and verify offline operation on the actual Android app.
