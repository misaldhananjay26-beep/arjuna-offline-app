# Build Arjuna Android APK

This is a new minimal Android WebView wrapper for the upgraded Arjuna offline web application.

## Requirements
- Android Studio with Android SDK Platform 35
- JDK 17
- Internet for the first Gradle dependency sync
- Android WebView installed on the target device

## Open and build
1. Open the `android-wrapper` folder in Android Studio.
2. Allow Gradle sync to complete.
3. Confirm SDK 35 is installed.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.

For a distributable release, create and securely store your own signing key, then use Build > Generate Signed Bundle / APK.

## Offline architecture
- Web content is packaged under `app/src/main/assets/www/`.
- WebViewAssetLoader serves the assets from the HTTPS-like `appassets.androidplatform.net` origin.
- This origin allows the web app's service worker to operate in a supported Android WebView.
- Simulation calculations and assets are local. External source links open outside the app.

## Important
This is a reconstructed minimal wrapper, not the original APK's Android project. The original floating overlay service is not reproduced in this first wrapper. Verify service-worker behaviour on the target Android System WebView version.
