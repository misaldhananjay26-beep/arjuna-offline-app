/* Arjuna Local Simulation Registry v1.0.0
 * Original offline-first learning modules. No remote runtime dependencies.
 */
(function (global) {
  'use strict';
  const labs = [
    {id:'projectile-motion',title:'Projectile Motion Lab',subject:'Physics',classes:['11','12'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Kinematics',level:'Advanced',description:'Explore trajectory, range, maximum height and flight time without air resistance.',controls:[
      {id:'speed',label:'Initial speed',min:5,max:50,step:1,value:20,unit:'m/s'},
      {id:'angle',label:'Launch angle',min:0,max:90,step:1,value:45,unit:'°'},
      {id:'gravity',label:'Gravity',min:1,max:20,step:.1,value:9.8,unit:'m/s²'}
    ],formula:'x = u cos(θ)t; y = u sin(θ)t − ½gt²',calculate:v=>{const a=v.angle*Math.PI/180,t=2*v.speed*Math.sin(a)/v.gravity;return [{label:'Range',value:(v.speed*v.speed*Math.sin(2*a)/v.gravity).toFixed(2),unit:'m'},{label:'Maximum height',value:(v.speed*v.speed*Math.sin(a)**2/(2*v.gravity)).toFixed(2),unit:'m'},{label:'Flight time',value:t.toFixed(2),unit:'s'}]}},
    {id:'vector-addition',title:'Vector Addition Lab',subject:'Physics',classes:['11','12'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Vectors',level:'Advanced',description:'Change vector magnitudes and directions to observe resultant magnitude and direction.',controls:[
      {id:'a',label:'Vector A',min:0,max:20,step:.5,value:10,unit:'units'},
      {id:'alpha',label:'Angle A',min:0,max:360,step:1,value:30,unit:'°'},
      {id:'b',label:'Vector B',min:0,max:20,step:.5,value:8,unit:'units'},
      {id:'beta',label:'Angle B',min:0,max:360,step:1,value:120,unit:'°'}
    ],formula:'Rₓ = ΣVᵢ cos θᵢ; Rᵧ = ΣVᵢ sin θᵢ',calculate:v=>{const x=v.a*Math.cos(v.alpha*Math.PI/180)+v.b*Math.cos(v.beta*Math.PI/180),y=v.a*Math.sin(v.alpha*Math.PI/180)+v.b*Math.sin(v.beta*Math.PI/180);return [{label:'Resultant',value:Math.hypot(x,y).toFixed(2),unit:'units'},{label:'Direction',value:((Math.atan2(y,x)*180/Math.PI+360)%360).toFixed(1),unit:'°'},{label:'X component',value:x.toFixed(2),unit:'units'},{label:'Y component',value:y.toFixed(2),unit:'units'}]}},
    {id:'newtons-second-law',title:"Newton's Second Law Lab",subject:'Physics',classes:['9','11'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Laws of Motion',level:'Core',description:'Investigate how net force and mass determine acceleration.',controls:[
      {id:'mass',label:'Mass',min:1,max:50,step:1,value:10,unit:'kg'},
      {id:'force',label:'Applied force',min:0,max:200,step:1,value:50,unit:'N'},
      {id:'friction',label:'Opposing force',min:0,max:100,step:1,value:10,unit:'N'}
    ],formula:'Fₙₑₜ = ma; a = (F − f) / m',calculate:v=>{const net=v.force-v.friction;return [{label:'Net force',value:net.toFixed(1),unit:'N'},{label:'Acceleration',value:(net/v.mass).toFixed(2),unit:'m/s²'},{label:'Mass',value:v.mass.toFixed(1),unit:'kg'}]}},
    {id:'work-energy',title:'Work and Energy Lab',subject:'Physics',classes:['9','11'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Work, Energy and Power',level:'Core',description:'Explore work done by a force and kinetic energy as speed and mass change.',controls:[
      {id:'mass',label:'Mass',min:1,max:30,step:1,value:5,unit:'kg'},
      {id:'speed',label:'Speed',min:0,max:30,step:.5,value:10,unit:'m/s'},
      {id:'force',label:'Force',min:0,max:100,step:1,value:20,unit:'N'},
      {id:'distance',label:'Displacement',min:0,max:20,step:.5,value:5,unit:'m'}
    ],formula:'K = ½mv²; W = Fs (force parallel to displacement)',calculate:v=>[{label:'Kinetic energy',value:(.5*v.mass*v.speed*v.speed).toFixed(2),unit:'J'},{label:'Work done',value:(v.force*v.distance).toFixed(2),unit:'J'},{label:'Power at this speed',value:(v.force*v.speed).toFixed(2),unit:'W'}]},
    {id:'circular-motion',title:'Circular Motion Lab',subject:'Physics',classes:['11','12'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Circular Motion',level:'Advanced',description:'Change speed and radius to investigate centripetal acceleration and force.',controls:[
      {id:'mass',label:'Mass',min:.5,max:20,step:.5,value:2,unit:'kg'},
      {id:'speed',label:'Speed',min:1,max:30,step:.5,value:10,unit:'m/s'},
      {id:'radius',label:'Radius',min:.5,max:20,step:.5,value:5,unit:'m'}
    ],formula:'a꜀ = v²/r; F꜀ = mv²/r; ω = v/r',calculate:v=>[{label:'Centripetal acceleration',value:(v.speed*v.speed/v.radius).toFixed(2),unit:'m/s²'},{label:'Centripetal force',value:(v.mass*v.speed*v.speed/v.radius).toFixed(2),unit:'N'},{label:'Angular speed',value:(v.speed/v.radius).toFixed(2),unit:'rad/s'}]},
    {id:'simple-pendulum',title:'Simple Pendulum Lab',subject:'Physics',classes:['9','11'],exams:['MHT-CET','JEE Main'],topic:'Oscillations',level:'Core',description:'Investigate the period of a simple pendulum for small angular displacement.',controls:[
      {id:'length',label:'Length',min:.1,max:3,step:.05,value:1,unit:'m'},
      {id:'gravity',label:'Gravity',min:1,max:20,step:.1,value:9.8,unit:'m/s²'},
      {id:'angle',label:'Initial angle',min:1,max:25,step:1,value:10,unit:'°'}
    ],formula:'T = 2π√(L/g), valid for small oscillations',calculate:v=>[{label:'Time period',value:(2*Math.PI*Math.sqrt(v.length/v.gravity)).toFixed(3),unit:'s'},{label:'Frequency',value:(1/(2*Math.PI*Math.sqrt(v.length/v.gravity))).toFixed(3),unit:'Hz'},{label:'Angular frequency',value:Math.sqrt(v.gravity/v.length).toFixed(3),unit:'rad/s'}]},
    {id:'ohms-law',title:"Ohm's Law and Circuit Lab",subject:'Physics',classes:['10','12'],exams:['MHT-CET','JEE Main'],topic:'Current Electricity',level:'Core',description:'Change voltage and resistance to calculate current and electrical power for an ohmic resistor.',controls:[
      {id:'voltage',label:'Voltage',min:0,max:24,step:.5,value:12,unit:'V'},
      {id:'resistance',label:'Resistance',min:1,max:100,step:1,value:6,unit:'Ω'}
    ],formula:'V = IR; P = VI = I²R',calculate:v=>{const i=v.voltage/v.resistance;return [{label:'Current',value:i.toFixed(3),unit:'A'},{label:'Power',value:(v.voltage*i).toFixed(2),unit:'W'},{label:'Resistance',value:v.resistance.toFixed(1),unit:'Ω'}]}},
    {id:'lens-equation',title:'Lens Formula and Ray Optics Lab',subject:'Physics',classes:['10','12'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Ray Optics',level:'Advanced',description:'Explore image position and magnification for a thin lens using the Cartesian sign convention.',controls:[
      {id:'focal',label:'Focal length',min:5,max:40,step:1,value:15,unit:'cm'},
      {id:'object',label:'Object distance magnitude',min:20,max:100,step:1,value:45,unit:'cm'}
    ],formula:'1/f = 1/v − 1/u; m = v/u (Cartesian convention)',calculate:v=>{const u=-v.object,f=v.focal;const den=(1/f)+(1/u);const image=1/den;return [{label:'Image distance v',value:image.toFixed(2),unit:'cm'},{label:'Magnification',value:(image/u).toFixed(3),unit:'×'},{label:'Image type',value:image>0?'Virtual':'Real',unit:''}] }},
    {id:'mole-concept',title:'Mole Concept and Stoichiometry Lab',subject:'Chemistry',classes:['11','12'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Some Basic Concepts',level:'Advanced',description:'Convert between mass, moles, particles and molar mass using Avogadro constant.',controls:[
      {id:'mass',label:'Sample mass',min:.1,max:200,step:.1,value:18,unit:'g'},
      {id:'molar',label:'Molar mass',min:1,max:300,step:1,value:18,unit:'g/mol'}
    ],formula:'n = m/M; N = nNₐ; Nₐ = 6.02214076 × 10²³ mol⁻¹',calculate:v=>{const n=v.mass/v.molar;return [{label:'Amount of substance',value:n.toFixed(4),unit:'mol'},{label:'Particles',value:(n*6.02214076).toExponential(4),unit:'particles'},{label:'Molar mass',value:v.molar.toFixed(1),unit:'g/mol'}]}},
    {id:'function-plotter',title:'Function Graph Explorer',subject:'Mathematics',classes:['11','12'],exams:['MHT-CET','JEE Main','JEE Advanced'],topic:'Functions',level:'Advanced',description:'Explore a family of quadratic functions and observe roots, vertex and axis of symmetry.',controls:[
      {id:'a',label:'Coefficient a',min:-4,max:4,step:.1,value:1,unit:''},
      {id:'b',label:'Coefficient b',min:-10,max:10,step:.5,value:0,unit:''},
      {id:'c',label:'Coefficient c',min:-10,max:10,step:.5,value:-4,unit:''}
    ],formula:'f(x) = ax² + bx + c; vertex x = −b/(2a)',calculate:v=>{const a=v.a||0.000001,x=-v.b/(2*a),y=a*x*x+v.b*x+v.c,d=v.b*v.b-4*a*v.c;return [{label:'Vertex x',value:x.toFixed(2),unit:''},{label:'Vertex y',value:y.toFixed(2),unit:''},{label:'Discriminant',value:d.toFixed(2),unit:''},{label:'Roots',value:d>=0?2:0,unit:'real'}]}}
  ];
  const byId = Object.fromEntries(labs.map(x=>[x.id,x]));
  global.ArjunaLabRegistry = {
    all:()=>labs.slice(),
    get:id=>byId[id]||null,
    findForRecord:r=>{
      if (r && r.localSimulationId && byId[r.localSimulationId]) return r.localSimulationId;
      const text=((r.concept||'')+' '+(r.topic||'')+' '+(r.activity||'')).toLowerCase();
      const rules=[
        [/projectile|trajectory/,'projectile-motion'],
        [/vector|resolution of vectors|resultant/,'vector-addition'],
        [/newton|laws of motion|force and laws/,'newtons-second-law'],
        [/work.*energy|kinetic energy|power/,'work-energy'],
        [/circular motion|centripetal/,'circular-motion'],
        [/pendulum|oscillation|simple harmonic/,'simple-pendulum'],
        [/ohm|current electricity|resistance|electric circuit/,'ohms-law'],
        [/lens|ray optics|image formation/,'lens-equation'],
        [/mole concept|moles|stoichiometry/,'mole-concept'],
        [/function|quadratic function|parabola|graph of a function/,'function-plotter']
      ];
      for(const [re,id] of rules) if(re.test(text)) return id;
      return null;
    }
  };
})(window);
