/* ============================================================
   ARJUNA — client-side search engine
   Zero dependencies. Scores the full 664-record index in ~1ms.
   Exposes window.ArjunaSearch
   ============================================================ */
(function (global) {
  'use strict';

  var records = [];
  var stats = null;

  var STATUS_RANK = {
    VERIFIED_DIRECT: 4,
    VERIFY_BEFORE_USE: 3,
    RELATED_PLATFORM_ONLY: 2,
    NO_DIRECT_SIMULATION: 1
  };

  function norm(s) {
    return String(s || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')   // strip accents
      .replace(/[^a-z0-9\s]/g, ' ')       // punctuation -> space
      .replace(/\s+/g, ' ')
      .trim();
  }

  function tokenize(q) {
    return norm(q).split(' ').filter(function (t) { return t.length > 0; });
  }

  /** Build the per-record search document once, at startup. */
  function init(data) {
    records = (data && data.records) || [];
    stats = (data && data.meta && data.meta.totals) || null;

    records.forEach(function (r) {
      r._concept = norm(r.concept);
      r._topic = norm(r.topic);
      r._where = norm([r.class, r.subject, r.platform].filter(Boolean).join(' '));
      r._body = norm([r.activity, r.note].filter(Boolean).join(' '));
      r._rank = STATUS_RANK[r.status] || 0;
    });
  }

  function fieldScore(haystack, token, weight) {
    if (!haystack) return 0;
    var idx = haystack.indexOf(token);
    if (idx === -1) return 0;
    var score = weight;
    // whole-word match is worth more than a substring match
    var before = idx === 0 ? ' ' : haystack.charAt(idx - 1);
    var after = haystack.charAt(idx + token.length) || ' ';
    if (before === ' ' && after === ' ') score += Math.round(weight * 0.6);
    return score;
  }

  function scoreRecord(r, tokens) {
    var total = 0;
    for (var i = 0; i < tokens.length; i++) {
      var t = tokens[i];
      var s =
        fieldScore(r._concept, t, 6) +
        fieldScore(r._topic, t, 4) +
        fieldScore(r._where, t, 3) +
        fieldScore(r._body, t, 2);
      if (s === 0) return 0;          // AND semantics: every token must hit
      total += s;
    }
    // small quality bonus so verified links surface first on ties
    total += r._rank * 0.8;
    if (r.url) total += 1;
    return total;
  }

  /**
   * Main query.
   * @param {string} q free text
   * @param {object} opts { class, subject, status, platform, hasLink, limit }
   * @returns {Array<{record, score}>} sorted best-first
   */
  function query(q, opts) {
    opts = opts || {};
    var tokens = tokenize(q);
    var out = [];

    for (var i = 0; i < records.length; i++) {
      var r = records[i];

      if (opts.class && r.class !== opts.class) continue;
      if (opts.subject && r.subject !== opts.subject) continue;
      if (opts.status && r.status !== opts.status) continue;
      if (opts.platform && r.platform !== opts.platform) continue;
      if (opts.hasLink && !r.url) continue;

      if (!tokens.length) {
        out.push({ record: r, score: r._rank + (r.url ? 1 : 0) });
        continue;
      }

      var s = scoreRecord(r, tokens);
      if (s > 0) out.push({ record: r, score: s });
    }

    out.sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return a.record.id - b.record.id;
    });

    return opts.limit ? out.slice(0, opts.limit) : out;
  }

  /**
   * Compact suggestions for the header / hero search box.
   * Returns { concepts:[...], topics:[...] }
   */
  function suggest(q, limit) {
    limit = limit || 7;
    var hits = query(q, { limit: limit });
    var tokens = tokenize(q);
    var topicMap = {};

    if (tokens.length) {
      records.forEach(function (r) {
        var hay = r._topic;
        for (var i = 0; i < tokens.length; i++) {
          if (hay.indexOf(tokens[i]) !== -1) {
            var key = r.class + '|' + r.subject + '|' + r.topic;
            if (!topicMap[key]) {
              topicMap[key] = { topic: r.topic, class: r.class, subject: r.subject, count: 0 };
            }
            topicMap[key].count++;
            return;
          }
        }
      });
    }

    var topics = Object.keys(topicMap).map(function (k) { return topicMap[k]; });
    topics.sort(function (a, b) { return b.count - a.count; });

    return {
      concepts: hits.map(function (h) { return h.record; }),
      topics: topics.slice(0, 3)
    };
  }

  /** Highlight `text` where any of `tokens` appear. Returns HTML (already escaped). */
  function highlight(text, tokens) {
    var escaped = String(text || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
    if (!tokens || !tokens.length) return escaped;

    var lower = escaped.toLowerCase();
    var spans = [];
    tokens.forEach(function (t) {
      if (t.length < 2) return;
      var from = 0, idx;
      while ((idx = lower.indexOf(t, from)) !== -1) {
        spans.push([idx, idx + t.length]);
        from = idx + t.length;
      }
    });
    if (!spans.length) return escaped;

    spans.sort(function (a, b) { return a[0] - b[0]; });
    var merged = [spans[0]];
    for (var i = 1; i < spans.length; i++) {
      var last = merged[merged.length - 1];
      if (spans[i][0] <= last[1]) last[1] = Math.max(last[1], spans[i][1]);
      else merged.push(spans[i]);
    }

    var html = '';
    var cursor = 0;
    merged.forEach(function (sp) {
      html += escaped.slice(cursor, sp[0]);
      html += '<mark>' + escaped.slice(sp[0], sp[1]) + '</mark>';
      cursor = sp[1];
    });
    return html + escaped.slice(cursor);
  }

  global.ArjunaSearch = {
    init: init,
    query: query,
    suggest: suggest,
    highlight: highlight,
    tokenize: tokenize,
    norm: norm,
    records: function () { return records; },
    stats: function () { return stats; }
  };
})(window);
