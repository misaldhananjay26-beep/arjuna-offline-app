/* Arjuna Offline Simulation Player v1.0.0 */
(function(global){
'use strict';
const copy={
 en:{back:'Back to concept',controls:'Experiment controls',results:'Live results',reset:'Reset values',save:'Save observation',saved:'Observation saved on this device',formula:'Scientific model',offline:'Runs locally. No internet required.',start:'Start',pause:'Pause',resume:'Resume',mode:'Exam mode'},
 hi:{back:'अवधारणा पर वापस',controls:'प्रयोग नियंत्रण',results:'लाइव परिणाम',reset:'मान रीसेट करें',save:'अवलोकन सहेजें',saved:'अवलोकन इस डिवाइस पर सहेजा गया',formula:'वैज्ञानिक मॉडल',offline:'स्थानीय रूप से चलता है। इंटरनेट आवश्यक नहीं।',start:'शुरू करें',pause:'रोकें',resume:'जारी रखें',mode:'परीक्षा मोड'},
 mr:{back:'संकल्पनेकडे परत',controls:'प्रयोग नियंत्रणे',results:'थेट निकाल',reset:'मूल्य रीसेट करा',save:'निरीक्षण जतन करा',saved:'निरीक्षण या डिव्हाइसवर जतन केले',formula:'वैज्ञानिक मॉडेल',offline:'स्थानिक पातळीवर चालते. इंटरनेट आवश्यक नाही.',start:'सुरू करा',pause:'थांबवा',resume:'पुन्हा सुरू करा',mode:'परीक्षा मोड'}
};
let current=null, values={}, raf=0, running=true, phase=0, lang='en';
const $=(s,r=document)=>r.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function t(k){return (copy[lang]||copy.en)[k]||copy.en[k]||k}
function defaults(lab){return Object.fromEntries(lab.controls.map(c=>[c.id,c.value]))}
function saveLocal(lab){
 const item={simulationId:lab.id,values:{...values},savedAt:new Date().toISOString(),version:'1.0.0'};
 try{const key='arjuna-lab-observations';const list=JSON.parse(localStorage.getItem(key)||'[]');list.unshift(item);localStorage.setItem(key,JSON.stringify(list.slice(0,100)));return true}catch(e){return false}
}
function metrics(lab){
 const out=lab.calculate(values);
 $('#lab-results').innerHTML=out.map(x=>`<div class="lab-metric"><span>${esc(x.label)}</span><strong>${esc(x.value)} <small>${esc(x.unit)}</small></strong></div>`).join('');
}
function draw(canvas,lab){
 const ctx=canvas.getContext('2d'),w=canvas.width=canvas.clientWidth*devicePixelRatio,h=canvas.height=canvas.clientHeight*devicePixelRatio;
 ctx.scale(devicePixelRatio,devicePixelRatio);const W=canvas.clientWidth,H=canvas.clientHeight;
 ctx.fillStyle='#0d1728';ctx.fillRect(0,0,W,H);
 ctx.strokeStyle='rgba(160,190,230,.12)';ctx.lineWidth=1;
 for(let x=25;x<W;x+=35){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
 for(let y=25;y<H;y+=35){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
 const line=(x1,y1,x2,y2,color='#79b8ff',width=3)=>{ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke()};
 const dot=(x,y,r=6,color='#49d6b1')=>{ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()};
 const text=(s,x,y,color='#dbeafe',size=12)=>{ctx.fillStyle=color;ctx.font=`${size}px system-ui`;ctx.fillText(s,x,y)};
 if(lab.id==='projectile-motion'){
  const a=values.angle*Math.PI/180,u=values.speed,g=values.gravity,T=2*u*Math.sin(a)/g,R=u*u*Math.sin(2*a)/g,Hm=u*u*Math.sin(a)**2/(2*g);
  const scale=Math.min((W-70)/Math.max(R,1),(H-60)/Math.max(Hm*1.35,1));
  line(28,H-28,W-12,H-28,'#8ba5c7',1);line(28,10,28,H-28,'#8ba5c7',1);
  ctx.strokeStyle='#49d6b1';ctx.lineWidth=3;ctx.beginPath();
  for(let i=0;i<=100;i++){const tt=T*i/100,x=u*Math.cos(a)*tt,y=u*Math.sin(a)*tt-.5*g*tt*tt,px=30+x*scale,py=H-30-y*scale;if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py)}ctx.stroke();
  const tt=running?(phase%1)*T:T*.5,x=u*Math.cos(a)*tt,y=u*Math.sin(a)*tt-.5*g*tt*tt;dot(30+x*scale,H-30-y*scale,7,'#ffcb69');
  text(`Range ${R.toFixed(1)} m`,W-120,22);text(`Max height ${Hm.toFixed(1)} m`,W-140,40);
 }else if(lab.id==='vector-addition'){
  const cx=W/2,cy=H/2,scale=Math.min(W,H)/52;
  line(15,cy,W-15,cy,'#8ba5c7',1);line(cx,12,cx,H-12,'#8ba5c7',1);
  const vec=(m,d,col)=>{const a=d*Math.PI/180,x=cx+m*Math.cos(a)*scale,y=cy-m*Math.sin(a)*scale;line(cx,cy,x,y,col,3);dot(x,y,5,col)};
  vec(values.a,values.alpha,'#49d6b1');vec(values.b,values.beta,'#ffcb69');
  const x=values.a*Math.cos(values.alpha*Math.PI/180)+values.b*Math.cos(values.beta*Math.PI/180),y=values.a*Math.sin(values.alpha*Math.PI/180)+values.b*Math.sin(values.beta*Math.PI/180);vec(Math.hypot(x,y),Math.atan2(y,x)*180/Math.PI,'#ff7c93');
  text('A',cx+values.a*scale*Math.cos(values.alpha*Math.PI/180)+5,cy-values.a*scale*Math.sin(values.alpha*Math.PI/180));text('B',cx+values.b*scale*Math.cos(values.beta*Math.PI/180)+5,cy-values.b*scale*Math.sin(values.beta*Math.PI/180));
 }else if(lab.id==='newtons-second-law'){
  const y=H*.58,x=35,bx=Math.min(W-110,100+values.force*2.1);line(20,y+38,W-15,y+38,'#8ba5c7',2);ctx.fillStyle='#467cb9';ctx.fillRect(x,y,bx-x,38);text(`${values.mass} kg`,x+8,y+24);line(bx,y+19,Math.min(W-15,bx+65),y+19,'#ffcb69',4);text(`Fnet ${(values.force-values.friction).toFixed(1)} N`,25,28);
 }else if(lab.id==='work-energy'){
  const x=45,y=H*.55,sz=35+values.mass*2;ctx.fillStyle='#467cb9';ctx.fillRect(x,y-sz,sz,sz);line(15,y,W-15,y,'#8ba5c7',2);line(x+sz,y-sz/2,Math.min(W-20,x+sz+values.distance*18),y-sz/2,'#49d6b1',4);text(`v = ${values.speed} m/s`,25,25);text(`s = ${values.distance} m`,25,43);
 }else if(lab.id==='circular-motion'){
  const r=Math.min(W,H)*.31,cx=W/2,cy=H/2;ctx.strokeStyle='#49d6b1';ctx.lineWidth=3;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.stroke();const a=phase*2*Math.PI;const x=cx+r*Math.cos(a),y=cy+r*Math.sin(a);dot(x,y,9,'#ffcb69');line(cx,cy,x,y,'#ff7c93',2);text(`r = ${values.radius} m`,20,25);text(`v = ${values.speed} m/s`,20,43);
 }else if(lab.id==='simple-pendulum'){
  const cx=W/2,top=30,L=Math.min(H*.62,values.length*95),a=values.angle*Math.PI/180*Math.sin(phase*2*Math.PI);line(cx,top,cx+L*Math.sin(a),top+L*Math.cos(a),'#d5e6ff',3);dot(cx+L*Math.sin(a),top+L*Math.cos(a),12,'#ffcb69');dot(cx,top,5,'#49d6b1');text(`L = ${values.length} m`,20,H-20);
 }else if(lab.id==='ohms-law'){
  const y=H/2;line(40,y,W-40,y,'#49d6b1',3);ctx.strokeStyle='#ffcb69';ctx.lineWidth=3;ctx.strokeRect(W/2-28,y-20,56,40);text(`${values.resistance} Ω`,W/2-22,y+5);text(`${values.voltage} V`,25,30);text(`I = ${(values.voltage/values.resistance).toFixed(2)} A`,W-110,30);
 }else if(lab.id==='lens-equation'){
  const cx=W/2;line(15,H/2,W-15,H/2,'#8ba5c7',1);line(cx,25,cx,H-25,'#49d6b1',3);const f=values.focal,u=values.object,v=1/(1/f-1/u);const scale=Math.min((W*.35)/Math.max(u,Math.abs(v),f),3);line(cx-u*scale,H/2-30,cx-u*scale,H/2+30,'#ffcb69',3);line(cx+v*scale,H/2-25,cx+v*scale,H/2+25,'#ff7c93',3);text('Object',cx-u*scale-20,H/2+50);text('Lens',cx-12,H/2+65);text('Image',cx+v*scale-20,H/2+50);
 }else if(lab.id==='mole-concept'){
  const n=values.mass/values.molar,fill=Math.min(1,n/10);ctx.fillStyle='#233e5e';ctx.fillRect(W*.2,H*.35,W*.6,38);ctx.fillStyle='#49d6b1';ctx.fillRect(W*.2,H*.35,W*.6*fill,38);text(`${n.toFixed(3)} mol`,W*.2,H*.28);text('Mass → moles → particles',W*.2,H*.58);
 }else if(lab.id==='function-plotter'){
  const a=values.a||.00001,b=values.b,c=values.c,cx=W/2,cy=H/2,sx=W/18,sy=H/150;line(10,cy,W-10,cy,'#8ba5c7',1);line(cx,10,cx,H-10,'#8ba5c7',1);ctx.strokeStyle='#49d6b1';ctx.lineWidth=3;ctx.beginPath();for(let i=0;i<=W;i++){const x=(i-cx)/sx,y=a*x*x+b*x+c,py=cy-y*sy;if(i===0)ctx.moveTo(i,py);else ctx.lineTo(i,py)}ctx.stroke();text(`y = ${a.toFixed(1)}x² + ${b.toFixed(1)}x + ${c.toFixed(1)}`,18,22);
 }
}
function render(id,record){
 current=global.ArjunaLabRegistry.get(id);if(!current)return `<div class="container"><h1>Simulation unavailable</h1><a href="#/">Return home</a></div>`;
 values=defaults(current);running=true;phase=0;
 const controlHtml=current.controls.map(c=>`<label class="lab-control"><span><b>${esc(c.label)}</b><output id="out-${c.id}">${values[c.id]} ${esc(c.unit)}</output></span><input type="range" min="${c.min}" max="${c.max}" step="${c.step}" value="${c.value}" data-control="${c.id}"></label>`).join('');
 const cls=current.classes.map(x=>'Class '+x).join(' · ');
 return `<div class="container lab-page">
 <nav class="crumbs"><a href="#/">Home</a><span>/</span><a href="#/lab">Offline Lab Library</a><span>/</span><span>${esc(current.title)}</span></nav>
 <header class="page-head"><div class="page-head__kicker">ARJUNA OFFLINE LAB · ${esc(current.subject.toUpperCase())}</div><h1>${esc(current.title)}</h1><p>${esc(current.description)}</p><div class="lab-tags"><span>${esc(cls)}</span><span>${esc(current.exams.join(' · '))}</span><span>Offline bundled</span></div></header>
 <div class="lab-layout"><section class="lab-stage"><div class="lab-stage__bar"><strong>Interactive experiment</strong><span class="lab-live">● LOCAL ENGINE</span></div><canvas id="lab-canvas" aria-label="${esc(current.title)} visualization"></canvas><div class="lab-actions"><button class="btn btn--primary" id="lab-play">${t('pause')}</button><button class="btn" id="lab-reset">${t('reset')}</button><button class="btn" id="lab-save">${t('save')}</button></div><p class="lab-offline">✓ ${t('offline')}</p></section>
 <aside class="lab-side"><section class="lab-panel"><h2>${t('controls')}</h2>${controlHtml}</section><section class="lab-panel"><h2>${t('results')}</h2><div id="lab-results" class="lab-results"></div></section><section class="lab-panel"><h2>${t('formula')}</h2><p class="lab-formula">${esc(current.formula)}</p></section><section class="lab-panel"><label class="lab-select-label">Language / भाषा / भाषा<select id="lab-language"><option value="en">English</option><option value="hi">हिन्दी</option><option value="mr">मराठी</option></select></label><label class="lab-select-label">${t('mode')}<select id="lab-mode"><option>School</option><option>MHT-CET</option><option>JEE Main</option><option>JEE Advanced</option></select></label></section><div id="lab-save-status" class="lab-save-status" aria-live="polite"></div></aside></div>
 <div class="lab-bottom"><a class="btn" href="${record?'#/concept/'+record.id:'#/lab'}">← ${record?t('back'):'All experiments'}</a><span>Simulation model v1.0 · Original Arjuna implementation</span></div></div>`;
}
function wire(){
 if(!current)return;
 const canvas=$('#lab-canvas');if(!canvas)return;
 const update=()=>{metrics(current);draw(canvas,current)};
 current.controls.forEach(c=>{const el=$(`[data-control="${c.id}"]`);el.addEventListener('input',()=>{values[c.id]=Number(el.value);$('#out-'+c.id).textContent=values[c.id]+' '+c.unit;update()})});
 $('#lab-reset').addEventListener('click',()=>{values=defaults(current);current.controls.forEach(c=>{const el=$(`[data-control="${c.id}"]`);el.value=values[c.id];$('#out-'+c.id).textContent=values[c.id]+' '+c.unit});update()});
 $('#lab-play').addEventListener('click',e=>{running=!running;e.currentTarget.textContent=running?t('pause'):t('resume')});
 $('#lab-save').addEventListener('click',()=>{$('#lab-save-status').textContent=saveLocal(current)?t('saved'):'Could not save. Check device storage.'});
 $('#lab-language').addEventListener('change',e=>{lang=e.target.value;$('#lab-play').textContent=running?t('pause'):t('resume');$('#lab-reset').textContent=t('reset');$('#lab-save').textContent=t('save');});
 const loop=()=>{if(!document.getElementById('lab-canvas'))return;if(running)phase+=.006;draw(canvas,current);raf=requestAnimationFrame(loop)};
 cancelAnimationFrame(raf);update();loop();
}
global.ArjunaLabPlayer={render,wire};
})(window);
