/* ============================================================
   ARJUNA — application shell
   Hash router · views · in-platform link preview · loader
   ============================================================ */
(function () {
  'use strict';

  /* ---------------- configuration ---------------- */

  const PLATFORMS = {
    PhET: {
      mono: 'Ph', color: 'var(--ph-phet)', domain: 'phet.colorado.edu',
      site: 'https://phet.colorado.edu/',
      blurb: 'Free physics, chemistry and maths simulations from the University of Colorado Boulder.'
    },
    GeoGebra: {
      mono: 'Gg', color: 'var(--ph-geogebra)', domain: 'geogebra.org',
      site: 'https://www.geogebra.org/',
      blurb: 'Free interactive geometry, algebra, calculus and graphing tools.'
    },
    OLabs: {
      mono: 'OL', color: 'var(--ph-olabs)', domain: 'olabs.edu.in',
      site: 'https://www.olabs.edu.in/',
      blurb: 'Virtual labs and simulations for school science experiments (India).'
    },
    ChemCollective: {
      mono: 'Cc', color: 'var(--ph-chemcollective)', domain: 'chemcollective.org',
      site: 'https://www.chemcollective.org/',
      blurb: 'Free virtual labs and scenario-based activities from Carnegie Mellon University.'
    },
    MolView: {
      mono: 'Mv', color: 'var(--ph-molview)', domain: 'molview.org',
      site: 'https://molview.org/',
      blurb: 'Free molecular editor — draw and explore molecules in 2D and 3D.'
    }
  };

  const STATUS = {
    VERIFIED_DIRECT: { label: 'Verified direct', cls: 'verified', rank: 4,
      blurb: 'The activity/detail page was checked and found relevant to this concept.' },
    VERIFY_BEFORE_USE: { label: 'Verify before use', cls: 'verify', rank: 3,
      blurb: 'A plausible exact URL was found — open it once before assigning it to students.' },
    RELATED_PLATFORM_ONLY: { label: 'Related platform', cls: 'related', rank: 2,
      blurb: 'An official platform link, but broader than a one-to-one concept simulation.' },
    NO_DIRECT_SIMULATION: { label: 'No direct sim', cls: 'none', rank: 1,
      blurb: 'No trustworthy free interactive was retained — use textbooks, lectures and question practice.' }
  };

  const CLASSES = [
    { raw: 'Class 9', slug: 'class-9', label: 'Class 9', short: '9' },
    { raw: 'Class 10', slug: 'class-10', label: 'Class 10', short: '10' },
    { raw: 'Class 11', slug: 'class-11', label: 'Class 11', short: '11' },
    { raw: 'Class 12', slug: 'class-12', label: 'Class 12', short: '12' },
    { raw: 'Competitive overlay', slug: 'competitive', label: 'CET / JEE overlay', short: 'CET' }
  ];

  const SUBJECTS = {
    mathematics: { raw: 'Mathematics', label: 'Mathematics', mono: '∑', color: 'var(--math)' },
    physics: { raw: 'Physics', label: 'Physics', mono: 'Φ', color: 'var(--physics)' },
    chemistry: { raw: 'Chemistry', label: 'Chemistry', mono: '⚗', color: 'var(--chemistry)' }
  };

  const STATUS_ORDER = ['VERIFIED_DIRECT', 'VERIFY_BEFORE_USE', 'RELATED_PLATFORM_ONLY', 'NO_DIRECT_SIMULATION'];
  const PAGE_SIZE = 48;
  const EMBED_SUFFIXES = ['geogebra.org', 'chemcollective.org'];

  /* ---------------- data + indexes ---------------- */

  const DATA = window.ARJUNA_DATA;
  const byId = new Map();
  const classBySlug = new Map(CLASSES.map((c) => [c.slug, c]));
  const TOPICS = []; // {class,subject,topic,slug,records[]}

  function buildIndexes() {
    if (!DATA) return;
    DATA.records.forEach((r) => byId.set(r.id, r));
    const topicMap = new Map();
    DATA.records.forEach((r) => {
      const key = r.class + '|' + r.subject + '|' + r.topicSlug;
      if (!topicMap.has(key)) {
        const entry = { class: r.class, subject: r.subject, topic: r.topic, slug: r.topicSlug, records: [] };
        topicMap.set(key, entry);
        TOPICS.push(entry);
      }
      topicMap.get(key).records.push(r);
    });
  }

  /* ---------------- tiny helpers ---------------- */

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const esc = (s) =>
    String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const slugify = (s) =>
    String(s).toLowerCase().replace(/['’]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

  const classOf = (slug) => classBySlug.get(slug);
  const subjectOf = (slug) => SUBJECTS[slug];

  function platformInfo(name) {
    return PLATFORMS[name] || { mono: '?', color: 'var(--muted)', domain: '', site: '#', blurb: '' };
  }

  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return ''; }
  }

  function canEmbed(url) {
    if (!url) return false;
    const host = hostOf(url);
    return EMBED_SUFFIXES.some((s) => host === s || host.endsWith('.' + s));
  }

  const statusBadge = (status, extra) => {
    const s = STATUS[status] || STATUS.NO_DIRECT_SIMULATION;
    return `<span class="badge badge--${s.cls}">${esc(s.label)}${extra ? ' ' + esc(extra) : ''}</span>`;
  };

  function platformChip(name) {
    if (!name) return `<span class="platform-chip"><i style="background:var(--none)">—</i>No simulation</span>`;
    const p = platformInfo(name);
    return `<span class="platform-chip"><i style="background:${p.color}">${esc(p.mono)}</i>${esc(name)}</span>`;
  }

  const pathLine = (r) =>
    `${esc(r.class)} · ${esc(r.subject)} · <b>${esc(r.topic)}</b>`;

  function toast(msg) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.hidden = false;
    requestAnimationFrame(() => el.classList.add('is-show'));
    clearTimeout(toast._t);
    toast._t = setTimeout(() => {
      el.classList.remove('is-show');
      setTimeout(() => { el.hidden = true; }, 300);
    }, 2400);
  }

  function copy(text, label) {
    const done = () => toast((label || 'Copied') + ' ✓');
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done).catch(() => fallback());
    } else fallback();

    function fallback() {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); done(); } catch { toast('Copy failed'); }
      document.body.removeChild(ta);
    }
  }

  const icon = {
    arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg>',
    external: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4 10 14M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.1.1l2.4-2.4a5 5 0 0 0-7.1-7.1L11 5"/><path d="M14 11a5 5 0 0 0-7.1-.1l-2.4 2.4a5 5 0 0 0 7.1 7.1L13 19"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 4.5 4.5"/></svg>'
  };

  /* ---------------- shared partials ---------------- */

  function conceptCard(r, tokens) {
    const st = STATUS[r.status];
    const title = tokens ? ArjunaSearch.highlight(r.concept, tokens) : esc(r.concept);
    const desc = tokens ? ArjunaSearch.highlight(r.activity, tokens) : esc(r.activity);
    return `
      <a class="card concept-card" href="#/concept/${r.id}">
        <div class="concept-card__top">
          <h3>${title}</h3>
          ${statusBadge(r.status)}
        </div>
        <div class="concept-card__path">${pathLine(r)}</div>
        <p class="concept-card__desc">${desc}</p>
        <div class="concept-card__foot">
          ${platformChip(r.platform)}
          <span class="concept-card__cta">Preview ${icon.arrow}</span>
        </div>
      </a>`;
  }

  function subjectCard(subjectSlug, stats) {
    const s = subjectOf(subjectSlug);
    const pct = stats.concepts ? Math.round((stats.verified / stats.concepts) * 100) : 0;
    return `
      <a class="card subject-card" data-subject="${subjectSlug}" href="#/search?subject=${encodeURIComponent(s.raw)}">
        <div class="subject-card__top">
          <div class="subject-card__icon" aria-hidden="true">${s.mono}</div>
          <span class="chip chip--${subjectSlug}">${stats.concepts} concepts</span>
        </div>
        <h3>${s.label}</h3>
        <div class="subject-card__meta">
          <span><b>${stats.links}</b> live links</span>
          <span><b>${stats.verified}</b> verified</span>
        </div>
        <div class="subject-card__bar" title="${pct}% verified"><i style="width:${pct}%"></i></div>
        <span class="subject-card__link">Browse ${s.label} →</span>
      </a>`;
  }

  function crumbList(items) {
    return `<nav class="crumbs" aria-label="Breadcrumb">${items
      .map((it, i) => {
        const sep = i ? '<span aria-hidden="true">/</span>' : '';
        return sep + (it.href ? `<a href="${it.href}">${esc(it.label)}</a>` : `<span>${esc(it.label)}</span>`);
      })
      .join('')}</nav>`;
  }

  /* ---------------- router ---------------- */

  function parseHash() {
    const raw = (location.hash || '#/').replace(/^#/, '');
    const [pathPart, queryPart] = raw.split('?');
    const parts = pathPart.split('/').filter(Boolean);
    const query = {};
    if (queryPart) {
      new URLSearchParams(queryPart).forEach((v, k) => { query[k] = v; });
    }
    if (!parts.length) return { name: 'home', query };
    if (parts[0] === 'browse') {
      if (!parts[1]) return { name: 'browse', query };
      if (!parts[2]) return { name: 'class', cls: parts[1], query };
      if (!parts[3]) return { name: 'subject', cls: parts[1], subj: parts[2], query };
      return { name: 'topic', cls: parts[1], subj: parts[2], topic: parts[3], query };
    }
    if (parts[0] === 'search') return { name: 'search', query };
    if (parts[0] === 'concept') return { name: 'concept', id: parseInt(parts[1], 10), query };
    if (parts[0] === 'lab') return { name: parts[1] ? 'lab-player' : 'lab-library', id: parts[1] || null, query };
    if (parts[0] === 'about') return { name: 'about', query };
    if (parts[0] === 'mini') return { name: 'mini', query };
    return { name: '404', query };
  }

  let currentRoute = null;
  let searchReset = true;

  function render() {
    const route = parseHash();
    const main = $('#main');
    if (!main) return;

    // Quick find: the mini window floats above whatever page is already shown.
    // On a cold start / deep link we render the home view behind it.
    if (route.name === 'mini') {
      if (!main.innerHTML.trim()) { main.innerHTML = viewHome(); afterRender({ name: 'home' }); }
      markActiveNav(route);
      openMini(route.query && route.query.q);
      currentRoute = { ...route, key: keyOf(route) };
      return;
    }
    closeMini();

    const isSearch = route.name === 'search';
    if (isSearch && searchReset) searchShown = PAGE_SIZE;
    if (!isSearch) searchReset = true;

    let html;
    try {
      switch (route.name) {
        case 'home': html = viewHome(); break;
        case 'browse': html = viewBrowse(); break;
        case 'class': html = viewClass(route.cls); break;
        case 'subject': html = viewSubject(route.cls, route.subj); break;
        case 'topic': html = viewTopic(route.cls, route.subj, route.topic); break;
        case 'search': html = viewSearch(route.query); break;
        case 'concept': html = viewConcept(route.id); break;
        case 'lab-library': html = viewLabLibrary(); break;
        case 'lab-player': html = viewLabPlayer(route.id); break;
        case 'about': html = viewAbout(); break;
        default: html = view404();
      }
    } catch (err) {
      console.error('Arjuna render error:', err);
      html = view404();
    }
    if (isSearch) searchReset = false;

    main.innerHTML = html;
    main.classList.remove('is-entering');
    void main.offsetWidth; // restart entrance animation
    main.classList.add('is-entering');

    markActiveNav(route);
    afterRender(route);

    if (currentRoute !== null && (!currentRoute || currentRoute.name !== route.name || currentRoute.key !== keyOf(route))) {
      window.scrollTo({ top: 0, behavior: 'auto' });
    }
    currentRoute = { ...route, key: keyOf(route) };
  }

  const keyOf = (r) => [r.name, r.cls, r.subj, r.topic, r.id].filter((x) => x != null).join('/');

  function markActiveNav(route) {
    const map = { home: 'home', browse: 'browse', class: 'browse', subject: 'browse', topic: 'browse', search: 'library', 'lab-library': 'lab', 'lab-player': 'lab', about: 'about' };
    const active = map[route.name] || '';
    $$('#main-nav a').forEach((a) => a.classList.toggle('is-active', a.dataset.nav === active));
    const nav = $('#main-nav');
    if (nav) nav.classList.remove('is-open');
    const mt = $('#menu-toggle');
    if (mt) mt.setAttribute('aria-expanded', 'false');
  }

  function afterRender(route) {
    if (route.name === 'search') wireSearchView(route.query);
    if (route.name === 'concept') wireConceptView(route.id);
    if (route.name === 'lab-player' && window.ArjunaLabPlayer) window.ArjunaLabPlayer.wire();
    if (route.name === 'home') attachSuggest('hero-search', 'hero-suggestions', {});
    if (route.name === 'search') {
      const lib = $('#lib-search');
      if (lib && !isTouch()) lib.focus({ preventScroll: true });
    }
    activateMotion(route);
  }

  const isTouch = () => window.matchMedia('(hover: none)').matches;

  /* ---------------- motion: scroll reveal, stat counters, scroll chrome ---------------- */

  const prefersReduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let revealObserver = null;
  let revealTimer = null;

  function activateMotion(route) {
    const targets = $$('#main .section__head, #main .grid > *, #main .class-strip > *, #main .legend-grid > *, #main .platform-grid > *, #main .detail__layout > *, #main .results-bar, #main .filters, #main .page-head');

    if (revealObserver) { revealObserver.disconnect(); revealObserver = null; }
    if (revealTimer) { clearInterval(revealTimer); revealTimer = null; }

    const show = (el) => el.setAttribute('data-reveal', 'in');

    if (targets.length && prefersReduced()) {
      targets.forEach(show);
    } else if (targets.length) {
      let pending = targets.slice();
      targets.forEach((el, i) => {
        el.setAttribute('data-reveal', '');
        el.style.setProperty('--d', `${(i % 8) * 55}ms`);
      });

      if ('IntersectionObserver' in window) {
        revealObserver = new IntersectionObserver((entries) => {
          entries.forEach((en) => {
            if (!en.isIntersecting) return;
            show(en.target);
            revealObserver.unobserve(en.target);
          });
        }, { rootMargin: '0px 0px -5% 0px', threshold: 0.06 });
        targets.forEach((el) => revealObserver.observe(el));
      }

      // safety sweep: reveals anything in view even when observer callbacks are
      // starved (headless/off-main-thread rendering); clears itself when done
      revealTimer = setInterval(() => {
        pending = pending.filter((el) => {
          if (el.getAttribute('data-reveal') === 'in') return false;
          const r = el.getBoundingClientRect();
          if (r.top < window.innerHeight * 0.95) { show(el); revealObserver && revealObserver.unobserve(el); return false; }
          return true;
        });
        if (!pending.length) { clearInterval(revealTimer); revealTimer = null; }
      }, 600);
    }

    if (route.name === 'home') countUpStats();
    motionEnhance(route);
  }

  function countUpStats() {
    if (prefersReduced()) return;
    $$('.hero__stats b').forEach((b) => {
      const m = /^(\d+)(.*)$/.exec(b.textContent.trim());
      if (!m) return;
      const end = parseInt(m[1], 10);
      const suffix = m[2] || '';
      if (!end || end > 100000) return;
      const dur = 1000;
      const t0 = Date.now();
      b.textContent = '0' + suffix;
      const tick = () => {
        const t = Math.min(1, Math.max(0, (Date.now() - t0) / dur)); // clamped: clocks can jump under virtual time
        b.textContent = Math.round(end * (1 - Math.pow(1 - t, 3))) + suffix;
        if (t < 1) setTimeout(tick, 40);
      };
      setTimeout(tick, 40);
    });
  }

  function initScrollChrome() {
    const header = $('#site-header');
    const bar = $('#scroll-progress');
    let ticking = false;
    const update = () => {
      ticking = false;
      const y = window.scrollY || 0;
      if (header) header.classList.toggle('is-scrolled', y > 8);
      if (bar) {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.width = max > 40 ? `${Math.min(100, (y / max) * 100)}%` : '0%';
      }
    };
    window.addEventListener('scroll', () => {
      if (!ticking) { ticking = true; requestAnimationFrame(update); }
    }, { passive: true });
    window.addEventListener('resize', update, { passive: true });
    update();
  }

  /* ---------------- view: home ---------------- */

  function viewHome() {
    const t = DATA.meta.totals;
    const verifiedPct = Math.round((t.verified / t.concepts) * 100);

    // subject stats
    const subjStats = {};
    Object.keys(SUBJECTS).forEach((k) => { subjStats[k] = { concepts: 0, verified: 0, links: 0 }; });
    DATA.records.forEach((r) => {
      const k = slugify(r.subject);
      if (!subjStats[k]) return;
      subjStats[k].concepts++;
      if (r.status === 'VERIFIED_DIRECT') subjStats[k].verified++;
      if (r.url) subjStats[k].links++;
    });

    // class pills
    const classPills = CLASSES.map((c) => {
      const n = DATA.meta.byClass[c.raw] || 0;
      return `<a class="class-pill" href="#/browse/${c.slug}">${esc(c.label)} <b>${n}</b></a>`;
    }).join('');

    // featured: verified simulations spread deterministically across the set
    const verified = DATA.records.filter((r) => r.status === 'VERIFIED_DIRECT' && r.url);
    const step = Math.max(1, Math.floor(verified.length / 9));
    const featured = [];
    for (let i = 0; i < verified.length && featured.length < 9; i += step) featured.push(verified[i]);

    const platforms = Object.entries(DATA.meta.byPlatform)
      .sort((a, b) => b[1] - a[1])
      .map(([name, count]) => {
        const p = platformInfo(name);
        return `
          <div class="card platform-card">
            ${platformChip(name)}
            <p>${esc(p.blurb)}</p>
            <span class="platform-card__count">${count} linked concepts · ${esc(p.domain)}</span>
          </div>`;
      }).join('');

    const legend = STATUS_ORDER.map((key) => {
      const s = STATUS[key];
      const count = DATA.meta.byStatus[key] || 0;
      return `
        <div class="card legend-card">
          <div>${statusBadge(key)} <span class="muted small">${count} concepts</span></div>
          <p>${esc(s.blurb)}</p>
        </div>`;
    }).join('');

    return `
      <section class="hero">
        <div class="container hero__inner">
          <span class="hero__kicker">Physics · Chemistry · Mathematics — Classes 9 to 12</span>
          <h1>Every simulation you need,<br><span class="accent">indexed like an armoury.</span></h1>
          <p class="hero__sub">
            Arjuna is a systematic map from your syllabus to ${t.concepts} free interactive simulations,
            virtual labs and visualisers — sorted by class, subject and topic, checked for quality,
            and previewable right here.
          </p>

          <div class="searchbox searchbox--hero" id="hero-searchbox">
            <svg class="searchbox__icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="M16.5 16.5 L21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            <input id="hero-search" type="search" autocomplete="off" spellcheck="false"
              placeholder="Try “thermodynamics”, “trigonometry”, “forces”…"
              aria-label="Search simulations" aria-expanded="false" aria-controls="hero-suggestions" role="combobox" />
            <div class="suggest" id="hero-suggestions" role="listbox" aria-label="Search suggestions" hidden></div>
          </div>

          <ul class="hero__stats">
            <li><b>${t.concepts}</b><span>Concepts</span></li>
            <li><b>${t.withLink}</b><span>Live links</span></li>
            <li><b>${verifiedPct}%</b><span>Verified</span></li>
            <li><b>${t.topics}</b><span>Topics</span></li>
            <li><b>${t.platforms}</b><span>Platforms</span></li>
          </ul>
        </div>
      </section>

      <section class="section" style="padding-top:0">
        <div class="container">
          <div class="section__head">
            <div><h2>Pick your class</h2><p class="sub">Structured exactly like the syllabus you study.</p></div>
            <a class="section__link" href="#/browse">Browse all →</a>
          </div>
          <div class="class-strip">${classPills}</div>
        </div>
      </section>

      <section class="section" style="padding-top:8px">
        <div class="container">
          <div class="section__head">
            <div><h2>Three subjects, one index</h2><p class="sub">Coverage and verified-link ratio per subject.</p></div>
          </div>
          <div class="grid grid--3">
            ${subjectCard('mathematics', subjStats.mathematics)}
            ${subjectCard('physics', subjStats.physics)}
            ${subjectCard('chemistry', subjStats.chemistry)}
          </div>
        </div>
      </section>

      <section class="section" style="padding-top:8px">
        <div class="container">
          <div class="section__head">
            <div><h2>Start with a verified simulation</h2><p class="sub">Hand-checked links across all three subjects.</p></div>
            <a class="section__link" href="#/search?status=VERIFIED_DIRECT">See all ${t.verified} →</a>
          </div>
          <div class="grid grid--3">${featured.map((r) => conceptCard(r)).join('')}</div>
        </div>
      </section>

      <section class="section" style="padding-top:8px">
        <div class="container">
          <div class="section__head">
            <div><h2>What the status labels mean</h2><p class="sub">Every concept carries an honest verification status — no invented links.</p></div>
          </div>
          <div class="legend-grid">${legend}</div>
        </div>
      </section>

      <section class="section" style="padding-top:8px">
        <div class="container">
          <div class="section__head">
            <div><h2>Platforms we index</h2><p class="sub">Free, reputable and classroom-safe sources only.</p></div>
          </div>
          <div class="platform-grid">${platforms}</div>
          <div class="note-banner" style="margin-top:22px">
            <span aria-hidden="true">◆</span>
            <div>
              <b>Built by Dhananjay Misal.</b> Arjuna never invents URLs: gaps are marked
              <em>NO_DIRECT_SIMULATION</em> so you know what to teach with a textbook instead.
              Always open a <em>verify-before-use</em> link once before assigning it.
            </div>
          </div>
        </div>
      </section>`;
  }

  /* ---------------- view: browse ---------------- */

  function viewBrowse() {
    const cards = CLASSES.map((c) => {
      const count = DATA.meta.byClass[c.raw] || 0;
      const recs = DATA.records.filter((r) => r.class === c.raw);
      const verified = recs.filter((r) => r.status === 'VERIFIED_DIRECT').length;
      const links = recs.filter((r) => r.url).length;
      const subjChips = Object.values(SUBJECTS)
        .filter((s) => recs.some((r) => r.subject === s.raw))
        .map((s) => `<span class="chip chip--${slugify(s.raw)}">${s.label}</span>`)
        .join('');
      return `
        <a class="card class-card" href="#/browse/${c.slug}">
          <span class="class-card__num">${esc(c.short)}</span>
          <h3>${esc(c.label)}</h3>
          <div class="class-card__row">${subjChips}</div>
          <div class="subject-card__meta">
            <span><b>${count}</b> concepts</span>
            <span><b>${links}</b> live links</span>
            <span><b>${verified}</b> verified</span>
          </div>
          <span class="topic-card__go">Open class →</span>
        </a>`;
    }).join('');

    return `
      <div class="container">
        <header class="page-head">
          <div class="page-head__kicker">Browse</div>
          <h1>Class by class, topic by topic</h1>
          <p>Every concept from the syllabus — ${DATA.meta.totals.concepts} in total — grouped the way your textbooks are.</p>
        </header>
        <section class="section">
          <div class="grid grid--3">${cards}</div>
        </section>
      </div>`;
  }

  function viewClass(clsSlug) {
    const cls = classOf(clsSlug);
    if (!cls) return view404();
    const recs = DATA.records.filter((r) => r.class === cls.raw);

    const cards = Object.entries(SUBJECTS).map(([sSlug, s]) => {
      const sub = recs.filter((r) => r.subject === s.raw);
      if (!sub.length) return '';
      const topics = new Set(sub.map((r) => r.topic)).size;
      const links = sub.filter((r) => r.url).length;
      const verified = sub.filter((r) => r.status === 'VERIFIED_DIRECT').length;
      return `
        <a class="card class-card" href="#/browse/${clsSlug}/${sSlug}">
          <div class="subject-card__icon" style="color:${s.color};background:color-mix(in srgb, ${s.color} 14%, transparent);border-color:color-mix(in srgb, ${s.color} 34%, transparent)" aria-hidden="true">${s.mono}</div>
          <h3>${s.label}</h3>
          <div class="subject-card__meta">
            <span><b>${topics}</b> topics</span>
            <span><b>${sub.length}</b> concepts</span>
            <span><b>${links}</b> links</span>
            <span><b>${verified}</b> verified</span>
          </div>
          <span class="topic-card__go">Open ${s.label} →</span>
        </a>`;
    }).join('');

    return `
      <div class="container">
        <header class="page-head">
          ${crumbList([{ label: 'Home', href: '#/' }, { label: 'Browse', href: '#/browse' }, { label: cls.label }])}
          <div class="page-head__kicker">${recs.length} concepts</div>
          <h1>${esc(cls.label)}</h1>
          <p>${clsSlug === 'competitive'
            ? 'MHT-CET / JEE Main / JEE Advanced skill overlay mapped onto simulations where they exist.'
            : 'Choose a subject to see its topics and every concept inside them.'}</p>
        </header>
        <section class="section">
          <div class="grid grid--3">${cards}</div>
        </section>
      </div>`;
  }

  function viewSubject(clsSlug, subjSlug) {
    const cls = classOf(clsSlug);
    const subj = subjectOf(subjSlug);
    if (!cls || !subj) return view404();

    const recs = DATA.records.filter((r) => r.class === cls.raw && r.subject === subj.raw);
    if (!recs.length) return view404();

    const topics = TOPICS.filter((t) => t.class === cls.raw && t.subject === subj.raw);
    const cards = topics.map((t) => {
      const links = t.records.filter((r) => r.url).length;
      const verified = t.records.filter((r) => r.status === 'VERIFIED_DIRECT').length;
      const platforms = [...new Set(t.records.map((r) => r.platform).filter(Boolean))];
      return `
        <a class="card topic-card" href="#/browse/${clsSlug}/${subjSlug}/${t.slug}">
          <div class="topic-card__head">
            <h3>${esc(t.topic)}</h3>
            <span class="topic-card__count">${t.records.length}</span>
          </div>
          <div class="topic-card__stats">
            <span class="chip"><span class="dot dot--verified"></span>${verified} verified</span>
            <span class="chip"><span class="dot dot--related"></span>${links} links</span>
            ${platforms.length ? `<span class="chip">${platforms.length} platform${platforms.length > 1 ? 's' : ''}</span>` : ''}
          </div>
          <span class="topic-card__go">Open topic →</span>
        </a>`;
    }).join('');

    return `
      <div class="container">
        <header class="page-head">
          ${crumbList([
            { label: 'Home', href: '#/' },
            { label: cls.label, href: '#/browse/' + clsSlug },
            { label: subj.label, href: '#/browse/' + clsSlug + '/' + subjSlug }
          ])}
          <div class="page-head__kicker">${topics.length} topics · ${recs.length} concepts</div>
          <h1>${esc(subj.label)} — ${esc(cls.label)}</h1>
          <p>All ${esc(subj.label)} topics for ${esc(cls.label)}, with verified simulation counts per topic.</p>
        </header>
        <section class="section">
          <div class="grid grid--3">${cards}</div>
        </section>
      </div>`;
  }

  function viewTopic(clsSlug, subjSlug, topicSlug) {
    const cls = classOf(clsSlug);
    const subj = subjectOf(subjSlug);
    if (!cls || !subj) return view404();
    const entry = TOPICS.find((t) => t.class === cls.raw && t.subject === subj.raw && t.slug === topicSlug);
    if (!entry) return view404();

    const cards = entry.records.map((r) => conceptCard(r)).join('');
    const links = entry.records.filter((r) => r.url).length;

    return `
      <div class="container">
        <header class="page-head">
          ${crumbList([
            { label: 'Home', href: '#/' },
            { label: cls.label, href: '#/browse/' + clsSlug },
            { label: subj.label, href: '#/browse/' + clsSlug + '/' + subjSlug },
            { label: entry.topic }
          ])}
          <div class="page-head__kicker">${entry.records.length} concepts · ${links} live links</div>
          <h1>${esc(entry.topic)}</h1>
          <p>${esc(subj.label)} · ${esc(cls.label)}. Each card shows the concept, its verification status and an in-platform preview.</p>
        </header>
        <section class="section">
          <div class="grid grid--3">${cards}</div>
        </section>
      </div>`;
  }

  /* ---------------- view: library / search ---------------- */

  function readFilters(q) {
    return {
      q: q.q || '',
      class: q.class || '',
      subject: q.subject || '',
      status: q.status || '',
      platform: q.platform || '',
      hasLink: q.link === '1',
      sort: q.sort || 'relevance'
    };
  }

  function buildSearchHash(f) {
    const p = new URLSearchParams();
    if (f.q) p.set('q', f.q);
    if (f.class) p.set('class', f.class);
    if (f.subject) p.set('subject', f.subject);
    if (f.status) p.set('status', f.status);
    if (f.platform) p.set('platform', f.platform);
    if (f.hasLink) p.set('link', '1');
    if (f.sort && f.sort !== 'relevance') p.set('sort', f.sort);
    const qs = p.toString();
    return '#/search' + (qs ? '?' + qs : '');
  }

  function runFilters(f) {
    let hits = ArjunaSearch.query(f.q, {
      class: f.class, subject: f.subject, status: f.status,
      platform: f.platform, hasLink: f.hasLink
    });

    if (f.sort === 'status') {
      hits.sort((a, b) => (STATUS[b.record.status].rank - STATUS[a.record.status].rank) || a.record.id - b.record.id);
    } else if (f.sort === 'name') {
      hits.sort((a, b) => a.record.concept.localeCompare(b.record.concept));
    } else if (f.sort === 'class') {
      const order = Object.fromEntries(CLASSES.map((c, i) => [c.raw, i]));
      hits.sort((a, b) => (order[a.record.class] - order[b.record.class]) || a.record.id - b.record.id);
    }
    return hits;
  }

  function viewSearch(q) {
    const f = readFilters(q);
    const hits = runFilters(f);
    const tokens = ArjunaSearch.tokenize(f.q);

    const opts = (list, current, labelFn, valFn) =>
      list.map((item) => {
        const val = valFn(item);
        const label = labelFn(item);
        return `<option value="${esc(val)}" ${current === val ? 'selected' : ''}>${esc(label)}</option>`;
      }).join('');

    const shown = hits.slice(0, searchShown);

    const results = shown.map((h) => conceptCard(h.record, tokens)).join('');
    const moreLeft = hits.length - shown.length;

    const activeChips = [];
    if (f.class) activeChips.push(`<a class="chip" href="${buildSearchHash({ ...f, class: '' })}">${esc(f.class)} ✕</a>`);
    if (f.subject) activeChips.push(`<a class="chip" href="${buildSearchHash({ ...f, subject: '' })}">${esc(f.subject)} ✕</a>`);
    if (f.status) activeChips.push(`<a class="chip" href="${buildSearchHash({ ...f, status: '' })}">${esc(STATUS[f.status] ? STATUS[f.status].label : f.status)} ✕</a>`);
    if (f.platform) activeChips.push(`<a class="chip" href="${buildSearchHash({ ...f, platform: '' })}">${esc(f.platform)} ✕</a>`);
    if (f.hasLink) activeChips.push(`<a class="chip" href="${buildSearchHash({ ...f, hasLink: false })}">Live links only ✕</a>`);

    return `
      <div class="container">
        <header class="page-head">
          <div class="page-head__kicker">Library</div>
          <h1>${f.q ? `Results for “${esc(f.q)}”` : 'The full simulation library'}</h1>
          <p>Search ${DATA.meta.totals.concepts} concepts across every class, subject, topic and platform.</p>
        </header>

        <div class="filters" role="search">
          <div class="searchbox">
            <svg class="searchbox__icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="M16.5 16.5 L21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            <input id="lib-search" type="search" value="${esc(f.q)}" placeholder="Search concepts, topics, platforms…"
              aria-label="Search library" autocomplete="off" spellcheck="false" />
          </div>
          <select id="f-class" aria-label="Filter by class">
            <option value="">All classes</option>
            ${opts(CLASSES, f.class, (c) => c.label, (c) => c.raw)}
          </select>
          <select id="f-subject" aria-label="Filter by subject">
            <option value="">All subjects</option>
            ${opts(Object.values(SUBJECTS), f.subject, (s) => s.label, (s) => s.raw)}
          </select>
          <select id="f-status" aria-label="Filter by status">
            <option value="">Any status</option>
            ${opts(STATUS_ORDER, f.status, (s) => STATUS[s].label, (s) => s)}
          </select>
          <select id="f-platform" aria-label="Filter by platform">
            <option value="">All platforms</option>
            ${opts(Object.keys(DATA.meta.byPlatform), f.platform, (p) => p, (p) => p)}
          </select>
          <label class="toggle"><input type="checkbox" id="f-link" ${f.hasLink ? 'checked' : ''} /> Live links only</label>
          <select id="f-sort" aria-label="Sort results">
            <option value="relevance" ${f.sort === 'relevance' ? 'selected' : ''}>Sort: Relevance</option>
            <option value="status" ${f.sort === 'status' ? 'selected' : ''}>Sort: Verified first</option>
            <option value="class" ${f.sort === 'class' ? 'selected' : ''}>Sort: Class order</option>
            <option value="name" ${f.sort === 'name' ? 'selected' : ''}>Sort: A–Z</option>
          </select>
        </div>

        <div class="results-bar">
          <span><b>${hits.length}</b> result${hits.length === 1 ? '' : 's'}${f.q ? ` for “${esc(f.q)}”` : ''}</span>
          ${activeChips.length ? `<span class="chip-row">${activeChips.join('')}</span>` : ''}
        </div>

        ${hits.length
          ? `<div class="grid grid--3">${results}</div>
             ${moreLeft > 0 ? `<div class="load-more"><button class="btn" id="load-more" type="button">Load ${Math.min(PAGE_SIZE, moreLeft)} more (${moreLeft} left)</button></div>` : ''}`
          : `<div class="empty-state">
               <h3>No concepts match those filters</h3>
               <p>Try a shorter search term, drop a filter, or browse the syllabus by class instead.</p>
               <a class="btn btn--primary" href="#/browse">Browse by class</a>
             </div>`}
        <div style="height:34px"></div>
      </div>`;
  }

  let searchShown = PAGE_SIZE;

  function wireSearchView(q) {
    const f = readFilters(q);

    const apply = (patch, reset) => {
      const next = { ...f, ...patch };
      if (reset) searchShown = PAGE_SIZE;
      history.replaceState(null, '', buildSearchHash(next));
      const keepFocus = patch && patch.keepFocus;
      const main = $('#main');
      main.innerHTML = viewSearch(parseHash().query);
      wireSearchView(parseHash().query);
      if (keepFocus) {
        const el = $('#lib-search');
        if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); }
      }
    };

    const input = $('#lib-search');
    if (input) {
      let timer = null;
      const commit = () => { clearTimeout(timer); apply({ q: input.value.trim(), keepFocus: true }, true); };
      input.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(commit, 220);
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); commit(); }
        if (e.key === 'Escape') { input.blur(); }
      });
    }

    const bind = (sel, ev, fn) => { const el = $(sel); if (el) el.addEventListener(ev, fn); };
    bind('#f-class', 'change', (e) => apply({ class: e.target.value }, true));
    bind('#f-subject', 'change', (e) => apply({ subject: e.target.value }, true));
    bind('#f-status', 'change', (e) => apply({ status: e.target.value }, true));
    bind('#f-platform', 'change', (e) => apply({ platform: e.target.value }, true));
    bind('#f-sort', 'change', (e) => apply({ sort: e.target.value }, true));
    bind('#f-link', 'change', (e) => apply({ hasLink: e.target.checked }, true));

    const more = $('#load-more');
    if (more) more.addEventListener('click', () => {
      searchShown += PAGE_SIZE;
      const scrollY = window.scrollY;
      $('#main').innerHTML = viewSearch(parseHash().query);
      wireSearchView(parseHash().query);
      window.scrollTo(0, scrollY);
    });
  }

  /* ---------------- view: concept detail + preview ---------------- */

  function viewConcept(id) {
    const r = byId.get(id);
    if (!r) return view404();

    const cls = CLASSES.find((c) => c.raw === r.class);
    const subjSlug = slugify(r.subject);
    const subj = subjectOf(subjSlug);
    const st = STATUS[r.status];
    const p = r.platform ? platformInfo(r.platform) : null;
    const embed = canEmbed(r.url);

    // preview panel
    let previewBody;
    if (r.url && embed) {
      previewBody = `
        <div class="preview__frame" id="preview-frame">
          <div class="preview__fallback" id="preview-loading">
            <div class="skeleton" style="width:56px;height:56px;border-radius:16px;min-height:0"></div>
            <p>Loading the live activity…</p>
          </div>
          <iframe id="preview-iframe" title="Live preview: ${esc(r.concept)}" hidden
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-presentation allow-downloads"
            referrerpolicy="strict-origin-when-cross-origin" allow="fullscreen; accelerometer; clipboard-write"></iframe>
        </div>`;
    } else if (r.url) {
      previewBody = `
        <div class="preview__frame">
          <div class="preview__fallback">
            <span class="mono-logo" style="background:${p.color}">${esc(p.mono)}</span>
            <h4>${esc(r.platform)}</h4>
            <p>${esc(p.blurb)}</p>
            <p><b>${esc(hostOf(r.url))}</b> doesn’t allow sites to embed its pages — the full activity opens in a new tab.</p>
            <div class="preview__actions">
              <a class="btn btn--primary" href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${icon.external} Open simulation</a>
              <button class="btn" type="button" id="copy-link">${icon.link} Copy link</button>
            </div>
          </div>
        </div>`;
    } else {
      previewBody = `
        <div class="preview__frame" style="aspect-ratio:auto;min-height:240px">
          <div class="preview__fallback">
            <span class="mono-logo" style="background:var(--surface-3);color:var(--muted)">—</span>
            <h4>No direct simulation retained</h4>
            <p>For this concept the research found no trustworthy free interactive. Study it with your textbook,
               lectures and question practice — the concept stays here so your tracking stays complete.</p>
            <div class="preview__actions">
              <a class="btn" href="#/browse/${esc(cls ? cls.slug : 'class-9')}/${subjSlug}">More from ${esc(r.topic)} →</a>
            </div>
          </div>
        </div>`;
    }

    const noteLine = r.note ? `<div class="preview__note"><b>Verification note:</b> ${esc(r.note)}</div>` : '';

    // related concepts from the same topic
    const related = DATA.records
      .filter((x) => x.class === r.class && x.subject === r.subject && x.topicSlug === r.topicSlug && x.id !== r.id)
      .slice(0, 6);

    const idx = DATA.records.indexOf(r);
    const prev = DATA.records[idx - 1];
    const next = DATA.records[idx + 1];

    return `
      <div class="container detail">
        ${crumbList([
          { label: 'Home', href: '#/' },
          { label: cls ? cls.label : r.class, href: cls ? '#/browse/' + cls.slug : '#/browse' },
          { label: subj ? subj.label : r.subject, href: '#/browse/' + (cls ? cls.slug : 'class-9') + '/' + subjSlug },
          { label: r.topic, href: '#/browse/' + (cls ? cls.slug : 'class-9') + '/' + subjSlug + '/' + r.topicSlug },
          { label: r.concept }
        ])}

        <div class="detail__layout">
          <div>
            <header class="detail__head">
              <div class="detail__badges">
                ${statusBadge(r.status)}
                <span class="chip chip--${subjSlug}">${esc(r.subject)}</span>
                <span class="chip">${esc(r.class)}</span>
                ${r.url ? `<span class="chip">${esc(hostOf(r.url))}</span>` : ''}
              </div>
              <h1>${esc(r.concept)}</h1>
              <p class="muted">${esc(r.topic)} · ${esc(r.subject)} · ${esc(r.class)}</p>
              ${window.ArjunaLabRegistry && window.ArjunaLabRegistry.findForRecord(r) ? `<div class="local-lab-cta"><div><strong>Try the Arjuna offline experiment</strong><p>Interactive controls and live calculations. Works without internet.</p></div><a class="btn btn--primary btn--sm" href="#/lab/${window.ArjunaLabRegistry.findForRecord(r)}">Open local lab →</a></div>` : ''}
            </header>

            <section class="preview" aria-label="In-platform preview">
              <div class="preview__bar">
                <span><b>In-platform preview</b> — ${r.platform ? esc(r.platform) : 'no linked platform'}</span>
                <span class="muted">${r.url ? (embed ? 'Live frame' : 'Details card') : 'Study guidance'}</span>
              </div>
              ${previewBody}
              ${r.url ? `<div class="preview__note"><b>Status:</b> ${esc(st.blurb)}</div>` : ''}
              ${noteLine}
            </section>

            <section class="detail__desc">
              <h2>How this helps</h2>
              <p>${esc(r.activity)}</p>
            </section>

            <div class="detail__nav">
              ${prev ? `<a class="btn btn--sm" href="#/concept/${prev.id}">← ${esc(prev.concept)}</a>` : '<span></span>'}
              ${next ? `<a class="btn btn--sm" href="#/concept/${next.id}">${esc(next.concept)} →</a>` : '<span></span>'}
            </div>
          </div>

          <aside class="side-panel">
            <h3>Details</h3>
            <dl class="meta-list">
              <div><dt>Status</dt><dd>${statusBadge(r.status)}</dd></div>
              <div><dt>Class</dt><dd>${esc(r.class)}</dd></div>
              <div><dt>Subject</dt><dd>${esc(r.subject)}</dd></div>
              <div><dt>Topic</dt><dd>${esc(r.topic)}</dd></div>
              <div><dt>Platform</dt><dd>${r.platform ? esc(r.platform) : '—'}</dd></div>
              <div><dt>Index ID</dt><dd>#${r.id}</dd></div>
              ${r.url ? `<div><dt>Source</dt><dd><a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${esc(hostOf(r.url))}</a></dd></div>` : ''}
            </dl>

            ${r.url ? `
              <a class="btn btn--primary" href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${icon.external} Open simulation</a>
              <button class="btn" type="button" id="copy-link">${icon.link} Copy link</button>
            ` : ''}

            ${related.length ? `
              <div>
                <h3 style="margin-bottom:10px">Same topic</h3>
                <div class="related-list">
                  ${related.map((x) => `<a href="#/concept/${x.id}">${esc(x.concept)}<span>${STATUS[x.status].label}${x.platform ? ' · ' + esc(x.platform) : ''}</span></a>`).join('')}
                </div>
              </div>` : ''}
          </aside>
        </div>
      </div>`;
  }

  function wireConceptView(id) {
    const r = byId.get(id);
    if (!r) return;

    $$('#copy-link').forEach((btn) =>
      btn.addEventListener('click', () => copy(r.url, 'Link copied'))
    );

    const iframe = $('#preview-iframe');
    if (iframe && r.url) {
      const loading = $('#preview-loading');
      let settled = false;
      const show = () => {
        if (settled) return;
        settled = true;
        iframe.hidden = false;
        if (loading) loading.remove();
      };
      iframe.addEventListener('load', show);
      iframe.src = r.url;
      // Fallback if the frame never arrives (slow network / blocked response)
      setTimeout(() => {
        if (settled) return;
        settled = true;
        const frame = $('#preview-frame');
        if (frame) {
          frame.innerHTML = `
            <div class="preview__fallback">
              <span class="mono-logo" style="background:${r.platform ? platformInfo(r.platform).color : 'var(--none)'}">${r.platform ? esc(platformInfo(r.platform).mono) : '—'}</span>
              <h4>Live preview timed out</h4>
              <p>${esc(r.platform || 'The platform')} is slow to respond right now. Open the activity in a new tab instead.</p>
              <div class="preview__actions">
                <a class="btn btn--primary" href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${icon.external} Open simulation</a>
                <button class="btn" type="button" id="retry-preview">Retry preview</button>
              </div>
            </div>`;
          const retry = $('#retry-preview');
          if (retry) retry.addEventListener('click', () => { render(); });
        }
      }, 14000);
    }
  }


  /* ---------------- local offline simulation library ---------------- */

  function viewLabLibrary() {
    const labs = window.ArjunaLabRegistry ? window.ArjunaLabRegistry.all() : [];
    return `<div class="container">
      <header class="page-head">
        <div class="page-head__kicker">ARJUNA OFFLINE LAB</div>
        <h1>Interactive Simulation Library</h1>
        <p>Original Arjuna experiments that run locally on your device, including without an internet connection.</p>
      </header>
      <div class="note-banner"><span aria-hidden="true">◆</span><div><b>Offline core library.</b> These experiments are bundled with this application. No external simulation website is required to run them.</div></div>
      <div class="lab-library-grid">${labs.map(l => `<a class="lab-library-card" href="#/lab/${encodeURIComponent(l.id)}">
        <div class="concept-card__top"><span class="chip chip--${l.subject.toLowerCase()}">${esc(l.subject)}</span><span class="status status--verified">Offline</span></div>
        <h3>${esc(l.title)}</h3><p>${esc(l.description)}</p>
        <div class="lab-card-meta">${l.classes.map(c=>`<span>Class ${c}</span>`).join('')} ${l.exams.map(e=>`<span>${esc(e)}</span>`).join('')}</div>
        <span class="concept-card__cta">Open experiment →</span>
      </a>`).join('')}</div>
    </div>`;
  }

  function viewLabPlayer(id) {
    const lab = window.ArjunaLabRegistry && window.ArjunaLabRegistry.get(id);
    if (!lab) return `<div class="container page-head"><h1>Simulation not found</h1><p>This local experiment is not included in this version.</p><a class="btn btn--primary" href="#/lab">Browse offline experiments</a></div>`;
    let record = null;
    const match = /^concept-(\d+)$/.exec(location.hash);
    if (match) record = byId.get(Number(match[1]));
    return window.ArjunaLabPlayer.render(id, record);
  }

  /* ---------------- view: about ---------------- */

  function viewAbout() {
    const notes = DATA.meta.notes || {};
    const t = DATA.meta.totals;

    const coverage = (() => {
      const rows = Object.keys(SUBJECTS).map((k) => {
        const s = SUBJECTS[k];
        const recs = DATA.records.filter((r) => r.subject === s.raw);
        const n = (fn) => recs.filter(fn).length;
        return `<tr>
          <td><strong>${s.label}</strong></td>
          <td class="num">${recs.length}</td>
          <td class="num">${n((r) => r.status === 'VERIFIED_DIRECT')}</td>
          <td class="num">${n((r) => r.status === 'VERIFY_BEFORE_USE')}</td>
          <td class="num">${n((r) => r.status === 'RELATED_PLATFORM_ONLY')}</td>
          <td class="num">${n((r) => r.status === 'NO_DIRECT_SIMULATION')}</td>
        </tr>`;
      }).join('');
      return `
        <div class="table-scroll" tabindex="0" role="region" aria-label="Coverage table (scrollable)">
          <table class="coverage-table">
            <thead><tr><th>Subject</th><th>Total</th><th>Verified</th><th>Verify first</th><th>Related</th><th>No sim</th></tr></thead>
            <tbody>${rows}</tbody>
            <tfoot><tr><td>All subjects</td><td class="num">${t.concepts}</td><td class="num">${t.verified}</td><td class="num">${t.verifyFirst}</td><td class="num">${t.relatedOnly}</td><td class="num">${t.noSimulation}</td></tr></tfoot>
          </table>
        </div>`;
    })();

    const legend = STATUS_ORDER.map((k) => {
      const s = STATUS[k];
      return `<li><strong>${statusBadge(k)}</strong> — ${esc(s.blurb)}</li>`;
    }).join('');

    return `
      <div class="container">
        <header class="page-head">
          <div class="page-head__kicker">About</div>
          <h1>How Arjuna was built</h1>
          <p>A concept-by-concept map from the syllabus to free interactive simulations — every gap marked honestly.</p>
        </header>

        <section class="section prose">
          <div class="note-banner" style="margin-bottom:26px">
            <span aria-hidden="true">◆</span>
            <div><b>Arjuna — made by Dhananjay Misal.</b> A research-driven index of
            ${t.concepts} PCM concepts and ${t.withLink} live simulation links for Classes 9–12,
            MHT-CET and JEE.</div>
          </div>

          <h2>Coverage</h2>
          ${coverage}

          <h2>Status policy</h2>
          <ul>${legend}</ul>

          <h2>Methodology notes</h2>
          ${Object.entries(notes).map(([k, v]) => `<h3>${esc(k)}</h3><p>${esc(v)}</p>`).join('')}

          <h2>Source</h2>
          <p>Built from <strong>${esc(DATA.meta.sourceDocument || 'PCM_Simulation_Links_Index.xlsx')}</strong> —
          a static index researched and curated from official platform sources. No URLs are invented:
          where no trustworthy free interactive was found, the concept is retained with
          <em>NO_DIRECT_SIMULATION</em> instead of a guess.</p>

          <div class="detail__nav" style="margin-top:30px">
            <a class="btn" href="#/browse">Browse by class</a>
            <a class="btn btn--primary" href="#/search">Open the library ${icon.arrow}</a>
          </div>
        </section>
      </div>`;
  }

  /* ---------------- view: 404 ---------------- */

  function view404() {
    return `
      <div class="container">
        <header class="page-head" style="padding-top:80px;text-align:center">
          <div class="page-head__kicker">404</div>
          <h1>Off target</h1>
          <p style="margin:0 auto 24px">That page isn’t in the index. Try a search or browse the syllabus.</p>
          <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
            <a class="btn btn--primary" href="#/">Back home</a>
            <a class="btn" href="#/search">Search library</a>
          </div>
        </header>
        <div style="height:60px"></div>
      </div>`;
  }

  /* ---------------- suggestion dropdowns ---------------- */

  function attachSuggest(inputId, panelId, opts) {
    const input = document.getElementById(inputId);
    const panel = document.getElementById(panelId);
    if (!input || !panel) return;
    if (input.dataset.suggestWired === '1') return;   // views are re-rendered; wire once
    input.dataset.suggestWired = '1';

    let items = [];
    let active = -1;
    let timer = null;

    const close = () => {
      panel.hidden = true;
      panel.innerHTML = '';
      input.setAttribute('aria-expanded', 'false');
      items = [];
      active = -1;
    };

    const open = () => {
      panel.hidden = false;
      input.setAttribute('aria-expanded', 'true');
    };

    const draw = () => {
      items = Array.from(panel.querySelectorAll('.suggest__item'));
      items.forEach((el, i) => el.classList.toggle('is-active', i === active));
      if (active >= 0 && items[active]) items[active].scrollIntoView({ block: 'nearest' });
    };

    const build = () => {
      const q = input.value.trim();
      if (q.length < 2) return close();

      const res = ArjunaSearch.suggest(q, 7);
      let html = '';

      if (res.concepts.length) {
        html += '<div class="suggest__label">Concepts</div>';
        res.concepts.forEach((r) => {
          html += `
            <a class="suggest__item" href="#/concept/${r.id}" role="option">
              <strong>${ArjunaSearch.highlight(r.concept, ArjunaSearch.tokenize(q))}</strong>
              <span>${esc(r.topic)} · ${esc(r.class)} · ${STATUS[r.status].label}${r.platform ? ' · ' + esc(r.platform) : ''}</span>
            </a>`;
        });
      }
      if (res.topics.length) {
        html += '<div class="suggest__label">Topics</div>';
        res.topics.forEach((t) => {
          const cls = CLASSES.find((c) => c.raw === t.class);
          const sSlug = slugify(t.subject);
          const tSlug = slugify(t.topic);
          html += `
            <a class="suggest__item" href="#/browse/${cls ? cls.slug : 'class-9'}/${sSlug}/${tSlug}" role="option">
              <strong>${esc(t.topic)}</strong>
              <span>${esc(t.subject)} · ${esc(t.class)} · ${t.count} concept${t.count > 1 ? 's' : ''}</span>
            </a>`;
        });
      }
      html += `<a class="suggest__item" href="#/search?q=${encodeURIComponent(q)}" role="option">
                 <strong>See all results for “${esc(q)}”</strong>
                 <span>Open the full library with filters</span>
               </a>`;

      if (!res.concepts.length && !res.topics.length && !ArjunaSearch.query(q, { limit: 1 }).length) {
        panel.innerHTML = `<div class="suggest__empty">No matches for “${esc(q)}”. Try a topic like <em>Trigonometry</em> or <em>Electrostatics</em>.</div>`;
        open();
        items = [];
        return;
      }

      panel.innerHTML = html;
      open();
      active = -1;
      draw();
    };

    input.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(build, 140);
    });

    input.addEventListener('focus', () => { if (input.value.trim().length >= 2) build(); });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); if (items.length) { active = (active + 1) % items.length; draw(); } }
      else if (e.key === 'ArrowUp') { e.preventDefault(); if (items.length) { active = (active - 1 + items.length) % items.length; draw(); } }
      else if (e.key === 'Enter') {
        if (active >= 0 && items[active]) { e.preventDefault(); location.hash = items[active].getAttribute('href').slice(1); close(); input.blur(); }
        else if (opts && opts.onEnter) { e.preventDefault(); opts.onEnter(input.value.trim()); close(); input.blur(); }
        else if (input.value.trim()) { e.preventDefault(); location.hash = '/search?q=' + encodeURIComponent(input.value.trim()); close(); input.blur(); }
      } else if (e.key === 'Escape') { close(); input.blur(); }
    });

    panel.addEventListener('click', (e) => {
      const item = e.target.closest('.suggest__item');
      if (item) setTimeout(close, 0);
    });

    document.addEventListener('click', (e) => {
      if (!panel.contains(e.target) && e.target !== input) close();
    });
  }

  function wireHero() { /* hero suggestions are wired in afterRender via attachSuggest */ }

  /* ---------------- quick find: floating launcher + mini window ----------------
     Two ways to use Arjuna:
       · Full app — the normal browsing experience (default on phones).
       · Quick find — a small floating window with search + results on top of the
         page. Smart-class TVs / interactive whiteboards launch straight into it
         (app icon shortcut, #/mini), search, then “maximize” into the full app. */

  let miniOpen = false;
  let miniWired = false;
  let miniActive = -1;
  let miniItems = [];
  let miniTimer = null;

  const miniInput = () => $('#mini-search');

  function modeGet() { try { return localStorage.getItem('arjuna-mode') || ''; } catch { return ''; } }
  function modeSet(m) { try { localStorage.setItem('arjuna-mode', m); } catch { /* private mode */ } }

  // Conservative 10-foot heuristic: TV/whiteboard browsers, or a big screen with
  // no pointer at all. Phones/tablets/desktops never match.
  function tvLike() {
    const ua = navigator.userAgent || '';
    if (/TV|BRAVIA|AFT|Android TV|Google TV|SmartTV|Smart-TV|HbbTV|Tizen|Web0S|WebOS|NetCast|VIDAA|Leanback|SHIELD|MiBOX|MiTV|FireTV|Roku/i.test(ua)) return true;
    try { return screen.width >= 1600 && window.matchMedia('(pointer: none)').matches; } catch { return false; }
  }

  function setMiniExpanded(on) {
    const input = miniInput();
    const win = $('#mini-window');
    if (input) input.setAttribute('aria-expanded', on ? 'true' : 'false');
    if (win) win.classList.toggle('has-results', !!on);
  }

  function openMini(initialQuery) {
    const root = $('#mini');
    if (!root) return;
    if (!miniOpen) {
      root.hidden = false;
      root.classList.add('is-open');
      document.body.classList.add('is-mini');
      const win = $('#mini-window');
      if (win) win.removeAttribute('style');   // clear any previous drag position
      miniOpen = true;
    }
    const input = miniInput();
    if (input && typeof initialQuery === 'string' && initialQuery) input.value = initialQuery;

    const counts = DATA && DATA.meta && DATA.meta.totals;
    const count = $('#mini-count');
    if (count && counts) count.innerHTML = `<b>${counts.concepts}</b> concepts · <b>${counts.topics}</b> topics`;

    miniRunSearch();
    setTimeout(() => { const el = miniInput(); if (el && miniOpen) el.focus({ preventScroll: true }); }, 40);
  }

  function closeMini() {
    const root = $('#mini');
    if (root && miniOpen) {
      root.hidden = true;
      root.classList.remove('is-open');
      document.body.classList.remove('is-mini');
      miniOpen = false;
    }
    miniActive = -1;
    miniItems = [];
  }

  function miniMaximize() {
    modeSet('full');
    const q = (miniInput() && miniInput().value.trim()) || '';
    location.hash = q ? ('/search?q=' + encodeURIComponent(q)) : '/search';
  }

  function miniExit() {
    modeSet('full');
    location.hash = '/';
  }

  function miniDraw() {
    miniItems.forEach((el, i) => el.classList.toggle('is-active', i === miniActive));
    if (miniActive >= 0 && miniItems[miniActive]) miniItems[miniActive].scrollIntoView({ block: 'nearest' });
  }

  function miniKeydown(e) {
    if (e.key === 'Escape') { e.preventDefault(); miniExit(); return; }
    if (e.key === 'Enter') {
      e.preventDefault();
      if (miniActive >= 0 && miniItems[miniActive]) {
        const href = miniItems[miniActive].getAttribute('href') || '';
        if (href) location.hash = href.replace(/^#/, '');
      } else if ((miniInput().value || '').trim()) {
        miniMaximize();
      }
      return;
    }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      if (!miniItems.length) return;
      e.preventDefault();
      miniActive = e.key === 'ArrowDown'
        ? (miniActive + 1) % miniItems.length
        : (miniActive - 1 + miniItems.length) % miniItems.length;
      miniDraw();
    }
  }

  function miniRunSearch() {
    const panel = $('#mini-results');
    const input = miniInput();
    if (!panel || !input) return;

    const q = input.value.trim();
    const tokens = ArjunaSearch.tokenize(q);
    let html = '';

    if (q.length >= 2) {
      const res = ArjunaSearch.suggest(q, 8);

      if (res.concepts.length) {
        html += '<div class="suggest__label">Concepts</div>';
        res.concepts.forEach((r) => {
          html += `<a class="suggest__item" href="#/concept/${r.id}" role="option">
              <strong>${ArjunaSearch.highlight(r.concept, tokens)}</strong>
              <span>${esc(r.topic)} · ${esc(r.class)} · ${STATUS[r.status].label}${r.platform ? ' · ' + esc(r.platform) : ''}</span>
            </a>`;
        });
      }
      if (res.topics.length) {
        html += '<div class="suggest__label">Topics</div>';
        res.topics.forEach((t) => {
          const cls = CLASSES.find((c) => c.raw === t.class);
          html += `<a class="suggest__item" href="#/browse/${cls ? cls.slug : 'class-9'}/${slugify(t.subject)}/${slugify(t.topic)}" role="option">
              <strong>${esc(t.topic)}</strong>
              <span>${esc(t.subject)} · ${esc(t.class)} · ${t.count} concept${t.count > 1 ? 's' : ''}</span>
            </a>`;
        });
      }
      html += `<a class="suggest__item" href="#/search?q=${encodeURIComponent(q)}" role="option">
            <strong>See all results for “${esc(q)}”</strong>
            <span>Open the full library with filters</span>
          </a>`;

      if (!res.concepts.length && !res.topics.length) {
        panel.innerHTML = `<div class="mini__empty">No matches for “${esc(q)}”. Try <em>Trigonometry</em>, <em>Electrostatics</em> or <em>Mole concept</em>.</div>`;
        miniItems = [];
        miniActive = -1;
        setMiniExpanded(true);
        return;
      }
    } else {
      html += '<div class="suggest__label">Start typing…</div>';
      ArjunaSearch.query('', { status: 'VERIFIED_DIRECT', limit: 6 }).forEach((h) => {
        const r = h.record;
        html += `<a class="suggest__item" href="#/concept/${r.id}" role="option">
            <strong>${esc(r.concept)}</strong>
            <span>${esc(r.topic)} · ${esc(r.class)}${r.platform ? ' · ' + esc(r.platform) : ''}</span>
          </a>`;
      });
    }

    panel.innerHTML = html;
    miniItems = Array.from(panel.querySelectorAll('.suggest__item'));
    miniActive = -1;
    setMiniExpanded(q.length > 0);
  }

  function initMiniDrag() {
    const handle = $('#mini-drag');
    const win = $('#mini-window');
    if (!handle || !win || !window.PointerEvent) return;
    let dragging = false, ox = 0, oy = 0, pid = null;

    handle.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      const r = win.getBoundingClientRect();
      dragging = true; pid = e.pointerId;
      win.style.position = 'fixed';
      win.style.margin = '0';
      win.style.bottom = 'auto';
      win.style.left = r.left + 'px';
      win.style.top = r.top + 'px';
      win.style.animation = 'none';
      win.style.transform = 'none';
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      win.classList.add('is-dragging');
      try { handle.setPointerCapture(pid); } catch { /* ignore */ }
    });

    handle.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const w = win.offsetWidth, h = win.offsetHeight;
      const x = Math.min(Math.max(0, e.clientX - ox), Math.max(0, window.innerWidth - w));
      const y = Math.min(Math.max(0, e.clientY - oy), Math.max(0, window.innerHeight - h));
      win.style.left = x + 'px';
      win.style.top = y + 'px';
    });

    const end = () => {
      if (!dragging) return;
      dragging = false;
      win.classList.remove('is-dragging');
      try { if (pid != null) handle.releasePointerCapture(pid); } catch { /* ignore */ }
      pid = null;
    };
    handle.addEventListener('pointerup', end);
    handle.addEventListener('pointercancel', end);
    handle.addEventListener('lostpointercapture', end);
  }

  function initMini() {
    if (miniWired) return;
    miniWired = true;

    const fab = $('#mini-fab');
    if (fab) fab.addEventListener('click', () => { modeSet('mini'); location.hash = '/mini'; });

    const max = $('#mini-maximize');
    if (max) max.addEventListener('click', miniMaximize);

    const full = $('#mini-open-full');
    if (full) full.addEventListener('click', miniMaximize);

    const closeBtn = $('#mini-close');
    if (closeBtn) closeBtn.addEventListener('click', miniExit);

    const backdrop = $('#mini-backdrop');
    if (backdrop) backdrop.addEventListener('click', miniExit);

    const input = $('#mini-search');
    if (input) {
      input.addEventListener('input', () => { clearTimeout(miniTimer); miniTimer = setTimeout(miniRunSearch, 130); });
      input.addEventListener('keydown', miniKeydown);
    }

    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && miniOpen) miniExit(); });

    initMiniDrag();
  }

  /* ---------------- theme / menu / misc chrome ---------------- */

  function initTheme() {
    const stored = localStorage.getItem('arjuna-theme');
    if (stored === 'light' || stored === 'dark') document.documentElement.dataset.theme = stored;
    updateThemeBtn();

    const btn = $('#theme-toggle');
    if (btn) btn.addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
      document.documentElement.dataset.theme = next;
      localStorage.setItem('arjuna-theme', next);
      updateThemeBtn();
    });

    function updateThemeBtn() {
      const b = $('#theme-toggle');
      if (!b) return;
      const isLight = document.documentElement.dataset.theme === 'light';
      b.setAttribute('aria-label', isLight ? 'Switch to dark theme' : 'Switch to light theme');
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute('content', isLight ? '#f6f7fa' : '#0b0c11');
    }
  }

  function initMenu() {
    const btn = $('#menu-toggle');
    const nav = $('#main-nav');
    if (!btn || !nav) return;
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', String(open));
      btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });

    // compact header: search icon (visible on small screens) jumps to the library
    const sf = $('#search-focus');
    if (sf) sf.addEventListener('click', () => {
      location.hash = '/search';
      setTimeout(() => {
        const el = $('#lib-search');
        if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); }
      }, 80);
    });
  }

  function initShortcuts() {
    document.addEventListener('keydown', (e) => {
      const tag = (e.target.tagName || '').toLowerCase();
      const typing = tag === 'input' || tag === 'textarea' || tag === 'select';
      if (e.key === '/' && !typing) {
        e.preventDefault();
        const header = $('#global-search');
        const hero = $('#hero-search');
        (hero || header || {}).focus?.();
      }
      if (e.key === 'k' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        const header = $('#global-search');
        if (header) header.focus();
      }
    });
  }

  function initSW() {
    if (!('serviceWorker' in navigator)) return;
    if (!/^https?:$/.test(location.protocol)) return;
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch(() => { /* offline support is a bonus */ });
    });
  }

  /* ---------------- motion layer (motion.dev) ----------------
     Progressive enhancement. Motion is vendored at assets/js/vendor/motion.js;
     if it is missing, gated off by prefers-reduced-motion, or on a touch-only
     device, every effect below is inert and the base UI is unchanged. Nothing
     here ever hides content, so a starved animation loop can never blank a view. */

  const MotionLib = (typeof window !== 'undefined' && window.Motion) ? window.Motion : null;
  const motionAllowed = () => !!MotionLib && !prefersReduced();
  let accentAnim = null;

  function motionInit() {
    if (!motionAllowed()) return;
    document.documentElement.classList.add('has-motion');
    motionScrollProgress();
  }

  // GPU-friendly reading-progress line via Motion's scroll tracking. Falls back
  // to the rAF width handler installed by initScrollChrome() when unavailable.
  // NB: Motion's `scroll(animation)` overload is a no-op here, so we use the
  // callback form, which is verified to track window scroll.
  function motionScrollProgress() {
    const bar = $('#scroll-progress');
    if (!bar) return false;
    try {
      MotionLib.scroll((progress) => {
        bar.style.transform = `scaleX(${progress.toFixed(4)})`;
      });
      bar.classList.add('is-motion');
      return true;
    } catch {
      bar.classList.remove('is-motion');
      return false;
    }
  }

  function motionEnhance(route) {
    if (!motionAllowed()) return;
    motionAccent(route);
    if (isTouch()) return; // magnetic + spotlight are pointer-only niceties
    motionMagnetic();
    motionSpotlight();
  }

  // Animated gradient on the hero headline accent.
  function motionAccent(route) {
    if (accentAnim && accentAnim.stop) { try { accentAnim.stop(); } catch { /* ignore */ } accentAnim = null; }
    if (route.name !== 'home') return;
    const acc = $('.hero h1 .accent');
    if (!acc) return;
    try {
      accentAnim = MotionLib.animate(
        acc,
        { backgroundPosition: ['0% 50%', '100% 50%'] },
        { duration: 7, repeat: Infinity, repeatType: 'mirror', easing: 'easeInOut' }
      );
    } catch { /* static gradient is fine */ }
  }

  // Magnetic primary actions: the control leans toward the pointer and springs back.
  function motionMagnetic() {
    $$('#main .btn--primary, #main .section__link, .mini-fab').forEach((el) => {
      if (el.dataset.magnet) return;
      el.dataset.magnet = '1';
      el.classList.add('is-magnetic');
      const strength = el.classList.contains('mini-fab') ? 0.34 : 0.22;
      let last = { x: 0, y: 0 };
      let clearTimer = 0;
      el.addEventListener('pointermove', (e) => {
        if (clearTimer) { clearTimeout(clearTimer); clearTimer = 0; }
        const r = el.getBoundingClientRect();
        last = {
          x: (e.clientX - (r.left + r.width / 2)) * strength,
          y: (e.clientY - (r.top + r.height / 2)) * strength
        };
        el.style.transform = `translate(${last.x.toFixed(2)}px, ${last.y.toFixed(2)}px)`;
      });
      const release = () => {
        if (last.x === 0 && last.y === 0) return;
        const from = last; last = { x: 0, y: 0 };
        // Always drop the inline transform: Motion's spring can stall if the tab
        // is backgrounded mid-flight (rAF paused) — never leave CSS hover/active blocked.
        const clear = () => {
          if (clearTimer) { clearTimeout(clearTimer); clearTimer = 0; }
          el.style.removeProperty('transform');
        };
        try {
          MotionLib.animate(el, { x: [from.x, 0], y: [from.y, 0] }, { type: 'spring', stiffness: 320, damping: 22 })
            .finished.then(clear, clear);
        } catch { clear(); return; }
        clearTimer = setTimeout(clear, 1500);
      };
      el.addEventListener('pointerleave', release);
      el.addEventListener('blur', release);
    });
  }

  // Spotlight that follows the cursor across a card (added as a child layer,
  // so it never collides with a card's own ::before/::after art). Card class and
  // attributes are left untouched — the smoke suite asserts on their exact strings.
  const spotlit = new WeakSet();
  function motionSpotlight() {
    $$('#main .card').forEach((card) => {
      if (spotlit.has(card)) return;
      spotlit.add(card);
      const spot = document.createElement('span');
      spot.className = 'spot';
      spot.setAttribute('aria-hidden', 'true');
      card.appendChild(spot);
      card.addEventListener('pointermove', (e) => {
        const r = card.getBoundingClientRect();
        spot.style.setProperty('--mx', `${(((e.clientX - r.left) / r.width) * 100).toFixed(1)}%`);
        spot.style.setProperty('--my', `${(((e.clientY - r.top) / r.height) * 100).toFixed(1)}%`);
      });
      card.addEventListener('pointerleave', () => {
        spot.style.setProperty('--mx', '50%');
        spot.style.setProperty('--my', '0%');
      });
    });
  }

  /* ---------------- boot / loading screen ---------------- */

  function boot() {
    const loader = $('#loader');
    const fill = $('#loader-fill');
    const status = $('#loader-status');
    const started = Date.now();

    const fatal = (msg) => {
      if (status) { status.textContent = msg; status.classList.add('loader__error'); }
      if (fill) fill.style.width = '100%';
    };

    if (!DATA || !Array.isArray(DATA.records) || !DATA.records.length) {
      fatal('Index could not be loaded. Run “npm run build” first.');
      return;
    }

    ArjunaSearch.init(DATA);
    buildIndexes();
    initTheme();
    initMenu();
    initShortcuts();
    initScrollChrome();
    initMini();
    motionInit();
    initSW();

    const total = DATA.meta.totals.concepts;
    const steps = [
      ['Waking the index…', 22],
      [`Loading ${total} concepts…`, 52],
      ['Ranking simulations…', 82],
      ['Ready — aim, Arjuna.', 100]
    ];

    let i = 0;
    const tick = () => {
      if (i >= steps.length) { finish(); return; }
      const [text, pct] = steps[i++];
      if (status) status.textContent = text;
      if (fill) fill.style.width = pct + '%';
      setTimeout(tick, 340);
    };

    const finish = () => {
      const wait = Math.max(0, 1250 - (Date.now() - started));
      setTimeout(() => {
        // Smart-class TVs / whiteboards: open in the small quick-find window first,
        // matching “tap the icon → small window → search → maximize”.
        if (tvLike() && modeGet() !== 'full' && (!location.hash || location.hash === '#/')) {
          try { history.replaceState(null, '', '#/mini'); } catch { /* ignore */ }
        }
        render();
        if (loader) {
          loader.classList.add('is-done');
          loader.setAttribute('aria-hidden', 'true');
          setTimeout(() => loader.remove(), 700);
        }
        const year = $('#year');
        if (year) year.textContent = String(new Date().getFullYear());
      }, wait);
    };

    // Hero/header search instances are created by views; wire them globally after boot
    attachSuggest('global-search', 'global-suggestions', {});
    attachSuggest('hero-search', 'hero-suggestions', {});

    window.addEventListener('hashchange', render);
    tick();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
