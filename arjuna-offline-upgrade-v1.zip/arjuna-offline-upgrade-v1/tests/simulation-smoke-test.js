// Run with: node tests/simulation-smoke-test.js
global.window = {};
require('../assets/js/simulations/registry.js');
const labs = window.ArjunaLabRegistry.all();
const assert = (ok, message) => { if (!ok) throw new Error(message); };
assert(labs.length === 10, 'Expected 10 bundled simulation modules');
const get = id => window.ArjunaLabRegistry.get(id);
const result = (id, values) => get(id).calculate(values);
let r = result('projectile-motion', {speed:20, angle:45, gravity:9.8});
assert(Math.abs(Number(r[0].value)-40.8163)<0.01, 'Projectile range baseline');
assert(Math.abs(Number(r[1].value)-10.2041)<0.01, 'Projectile height baseline');
r = result('ohms-law', {voltage:12, resistance:6});
assert(Number(r[0].value)===2, 'Ohm current baseline');
assert(Number(r[1].value)===24, 'Ohm power baseline');
r = result('simple-pendulum', {length:1, gravity:9.8, angle:10});
assert(Math.abs(Number(r[0].value)-2.006)<0.01, 'Pendulum period baseline');
r = result('mole-concept', {mass:18, molar:18});
assert(Number(r[0].value)===1, 'Mole amount baseline');
for (const lab of labs) {
  const values = Object.fromEntries(lab.controls.map(c => [c.id,c.value]));
  const outputs = lab.calculate(values);
  assert(outputs.length > 0, `No outputs for ${lab.id}`);
  assert(outputs.every(x => String(x.value).indexOf('NaN')===-1 && String(x.value)!=='Infinity'), `Invalid output for ${lab.id}`);
}
console.log(`PASS: ${labs.length} local simulation modules and scientific smoke checks.`);
