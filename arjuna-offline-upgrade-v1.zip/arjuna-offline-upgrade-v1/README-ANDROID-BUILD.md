# Build the Arjuna Android APK

This source bundle includes a reconstructed Android WebView wrapper. It is not the original Android Studio project and does not include the original signing key.

## Build with Android Studio

1. Extract this ZIP.
2. Open the `android-wrapper` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Build using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `android-wrapper/app/build/outputs/apk/debug/app-debug.apk`.

## Build with GitHub Actions

The Android wrapper uses Gradle 8.9, Android Gradle Plugin 8.7.3, Java 17, compile SDK 35, and AndroidX WebKit 1.12.1.

The web app is packaged in `android-wrapper/app/src/main/assets/www/`. `MainActivity` serves those local files through AndroidX WebViewAssetLoader at `https://appassets.androidplatform.net/assets/www/index.html`.

For a GitHub Actions build, extract this archive and build the `android-wrapper` directory with:

```bash
gradle --no-daemon -p arjuna-offline-upgrade-v1/android-wrapper clean assembleDebug
```

The resulting debug APK is unsigned for Play Store release purposes. It can be installed for local testing after enabling installation from the browser or file manager.

## Important limitations

- The wrapper and source are reconstructed from the recovered web assets. They are not the missing original Android Studio project.
- The original signing key and original Android overlay service were not recovered.
- The bundle currently contains 10 original local interactive simulation modules. It does not yet contain 664 fully offline interactive simulations.
- External simulation links and any online-only features still require internet access.
- The APK build and device behavior must be tested in GitHub Actions and on a physical Android device. This source bundle has not been independently compiled in this environment.
